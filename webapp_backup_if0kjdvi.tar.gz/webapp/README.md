# 🦷 DentalHub Pro
### Smart Dental Lab Management

A professional, full-featured **Dental Laboratory ERP and Case Management System** built with Hono + Cloudflare Pages + D1 Database.

---

## 🌐 Live URLs
- **App**: https://3000-if0kjdvi5la8nlhkfxkfq-5634da27.sandbox.novita.ai
- **Health**: https://3000-if0kjdvi5la8nlhkfxkfq-5634da27.sandbox.novita.ai/api/health

---

## 🔐 Demo Credentials

| Account | Email | Password | Access |
|---------|-------|----------|--------|
| **Admin (Operational)** | admin@dentalhub.pro | demo123 | Full access except finance |
| **Finance Manager** | finance@dentalhub.pro | demo123 | Finance-only access |
| **Technician (Ali)** | ali@dentalhub.pro | demo123 | Cases, workflow |
| **Designer (Sara)** | sara@dentalhub.pro | demo123 | Cases, files |

---

## ✅ Completed Features

### 🔑 Authentication
- Dual account system: **Operational** + **Finance** accounts
- Role-based access control (admin, technician, case_manager, finance, staff)
- JWT-like session tokens with expiry
- Sign up creates both accounts simultaneously
- Secure password hashing (SHA-256)

### 📊 Dashboard
- Live stats: Active cases, In Production, Ready for Delivery, Delayed
- Today's deliveries alert banner
- Monthly case volume bar chart
- Status overview with clickable filters
- Recent cases list

### 📁 Case Management
- Auto-generated Case IDs (LAB{id}-YYMM-XXXX)
- Full patient/clinic/dentist association
- 10 status workflow: Received → In Design → Milling → Printing → Finishing → Quality Check → Ready for Delivery → Completed → On Hold → Remake
- Priority levels: Low / Normal / High / Urgent
- Shade & Arch tracking
- Delayed case detection (red border)
- Case procedures with quantities and pricing

### 🔄 Case Workflow
- Status timeline with timestamps and technician names
- One-click status updates with notes
- Case conversation thread (chat-style notes)
- File attachment management (STL, CBCT, Photos, PDFs)
- Logistics/Delivery tracking (FedEx, DHL, UPS)
- Work ticket printing

### 🏥 Clinics Management
- Full clinic profiles (address, city, country, phone, email)
- Pricing plans (Basic/Standard/Premium)
- Case statistics per clinic
- Dentist management per clinic

### 👨‍⚕️ Dentist Management
- Full dentist profiles with specialties
- Clinic association
- Case history

### 🔍 Global Search
- Search across cases, clinics, and dentists
- Filter by type tabs

### 💰 Finance Module (Separate Account)
- Invoice generation per case
- Subtotal, discount, tax, delivery charge
- Payment recording (Bank Transfer, Cash, Card, Cheque)
- Auto-mark as paid when fully paid
- Finance dashboard with revenue charts
- Top clinics by revenue
- Monthly profit reports with bar charts

### 📈 Reports & Analytics
- Status breakdown (doughnut chart)
- Monthly case trend (line chart)
- Activity audit log

### 🌙 Dark Mode
- Full dark mode support with toggle
- Persistent across sessions

---

## 🏗️ Architecture

### Tech Stack
- **Backend**: Hono v4 (TypeScript) on Cloudflare Pages Workers
- **Database**: Cloudflare D1 (SQLite)
- **Frontend**: Vanilla JS + TailwindCSS CDN + Chart.js + FontAwesome
- **Build**: Vite + @hono/vite-build
- **Runtime**: Cloudflare Pages Edge

### Project Structure
```
webapp/
├── src/
│   ├── index.tsx          # Main Hono app + SPA HTML
│   ├── lib/auth.ts        # Auth utilities (hashing, sessions, logging)
│   └── routes/
│       ├── auth.ts        # Login, signup, logout, /me
│       ├── cases.ts       # Full case CRUD + dashboard stats
│       ├── clinics.ts     # Clinic management
│       ├── dentists.ts    # Dentist management
│       ├── finance.ts     # Invoices, payments, reports
│       ├── procedures.ts  # Procedure library
│       └── users.ts       # Users, notifications, activity logs
├── migrations/
│   └── 0001_initial_schema.sql   # Full DB schema
├── seed.sql               # Demo data
├── public/static/
│   ├── styles.css         # Full mobile UI CSS
│   └── app.js             # Complete SPA frontend
├── ecosystem.config.cjs   # PM2 config
├── wrangler.jsonc         # Cloudflare config
└── package.json
```

### Database Tables
- `users` — Lab staff with roles
- `labs` — Lab profiles
- `clinics` — Partner clinics
- `dentists` — Dentist profiles
- `cases` — Core case records
- `case_procedures` — Procedures per case
- `case_tracking` — Status timeline
- `case_notes` — Chat/communication
- `case_files` — Attached files
- `invoices` — Billing records
- `payments` — Payment records
- `activity_logs` — Audit trail
- `notifications` — Push notifications
- `sessions` — Auth sessions
- `procedures` — Procedure library

---

## 🚀 Deployment

### Local Development
```bash
npm run build
pm2 start ecosystem.config.cjs
```

### Deploy to Cloudflare Pages
```bash
# 1. Create D1 database
npx wrangler d1 create dentalhub-production
# Update database_id in wrangler.jsonc

# 2. Apply migrations
npx wrangler d1 migrations apply dentalhub-production

# 3. Deploy
npm run build && wrangler pages deploy dist --project-name dentalhub-pro
```

---

## 📱 Mobile Design
- Max-width 480px card-style layout
- Bottom navigation bar
- Floating Action Button (+) for new cases
- Bottom sheet modals
- Touch-friendly buttons (44px minimum)
- Smooth animations and transitions

---

*Built with ❤️ using DentalHub Pro | Powered by Cloudflare*
