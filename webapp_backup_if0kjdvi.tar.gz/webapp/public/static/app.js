// DentalHub Pro - Main App (Part 1: Core + Auth)
const API = '/api';
let currentUser = null;
let currentPage = 'dashboard';
let allCases = [];
let allClinics = [];
let allDentists = [];
let allProcedures = [];
let technicians = [];
let caseProcedures = [];
let darkMode = false;
let notifications = [];

// ===== API Helper =====
const api = {
  getToken: () => localStorage.getItem('dh_token'),
  headers: () => ({
    'Content-Type': 'application/json',
    'Authorization': 'Bearer ' + (localStorage.getItem('dh_token') || '')
  }),
  async get(path) {
    try {
      const r = await fetch(API + path, { headers: this.headers() });
      return await r.json();
    } catch(e) { return { error: e.message }; }
  },
  async post(path, data) {
    try {
      const r = await fetch(API + path, { method: 'POST', headers: this.headers(), body: JSON.stringify(data) });
      return await r.json();
    } catch(e) { return { error: e.message }; }
  },
  async put(path, data) {
    try {
      const r = await fetch(API + path, { method: 'PUT', headers: this.headers(), body: JSON.stringify(data) });
      return await r.json();
    } catch(e) { return { error: e.message }; }
  },
  async del(path) {
    try {
      const r = await fetch(API + path, { method: 'DELETE', headers: this.headers() });
      return await r.json();
    } catch(e) { return { error: e.message }; }
  }
};

// ===== Toast =====
function showToast(msg, type = 'success') {
  const icons = { success: 'fa-check-circle', error: 'fa-times-circle', warning: 'fa-exclamation-triangle', info: 'fa-info-circle' };
  const c = document.getElementById('toast-container') || (() => {
    const el = document.createElement('div');
    el.id = 'toast-container';
    el.className = 'toast-container';
    document.body.appendChild(el);
    return el;
  })();
  const t = document.createElement('div');
  t.className = `toast ${type}`;
  t.innerHTML = `<i class="fas ${icons[type] || icons.info}"></i><span>${msg}</span>`;
  c.appendChild(t);
  setTimeout(() => t.remove(), 3500);
}

// ===== Status helpers =====
const STATUS_MAP = {
  'Received': { cls: 'badge-received', icon: 'fa-inbox' },
  'In Design': { cls: 'badge-design', icon: 'fa-pen-nib' },
  'Milling': { cls: 'badge-milling', icon: 'fa-cog' },
  'Printing': { cls: 'badge-printing', icon: 'fa-print' },
  'Finishing': { cls: 'badge-finishing', icon: 'fa-magic' },
  'Quality Check': { cls: 'badge-quality', icon: 'fa-search' },
  'Ready for Delivery': { cls: 'badge-ready', icon: 'fa-box' },
  'Completed': { cls: 'badge-completed', icon: 'fa-check-circle' },
  'On Hold': { cls: 'badge-onhold', icon: 'fa-pause-circle' },
  'Remake': { cls: 'badge-remake', icon: 'fa-redo' }
};

function statusBadge(status) {
  const s = STATUS_MAP[status] || { cls: 'badge-received', icon: 'fa-circle' };
  return `<span class="badge ${s.cls}"><i class="fas ${s.icon}"></i>${status}</span>`;
}

const PRIORITY_MAP = { 'Urgent': 'badge-urgent', 'High': 'badge-high', 'Normal': 'badge-normal', 'Low': 'badge-low' };
function priorityBadge(p) { return `<span class="badge ${PRIORITY_MAP[p]||'badge-normal'}">${p}</span>`; }

function formatDate(d) {
  if (!d) return '—';
  const date = new Date(d);
  return date.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
}

function timeAgo(d) {
  if (!d) return '';
  const now = new Date(), date = new Date(d);
  const diff = now - date;
  if (diff < 60000) return 'just now';
  if (diff < 3600000) return Math.floor(diff/60000) + 'm ago';
  if (diff < 86400000) return Math.floor(diff/3600000) + 'h ago';
  return Math.floor(diff/86400000) + 'd ago';
}

function getInitials(name) {
  if (!name) return '?';
  return name.split(' ').map(w => w[0]).slice(0, 2).join('').toUpperCase();
}

// ===== Main App Entry =====
document.addEventListener('DOMContentLoaded', () => {
  const token = localStorage.getItem('dh_token');
  const savedUser = localStorage.getItem('dh_user');
  const savedDark = localStorage.getItem('dh_dark') === 'true';

  if (savedDark) { darkMode = true; document.documentElement.setAttribute('data-theme', 'dark'); }

  if (token && savedUser) {
    currentUser = JSON.parse(savedUser);
    initApp();
  } else {
    renderAuthPage();
  }
});

// ===== AUTH PAGE =====
function renderAuthPage() {
  document.getElementById('app').innerHTML = `
    <div class="auth-page">
      <div class="auth-logo">
        <div class="icon"><i class="fas fa-tooth"></i></div>
        <h1>DentalHub Pro</h1>
        <p>Smart Dental Lab Management</p>
      </div>
      <div class="auth-card">
        <div class="auth-tabs">
          <button class="auth-tab active" id="tab-login" onclick="switchAuthTab('login')">Login</button>
          <button class="auth-tab" id="tab-signup" onclick="switchAuthTab('signup')">Register Lab</button>
        </div>
        <div id="auth-form"></div>
      </div>
      <p style="color:rgba(255,255,255,0.7);font-size:12px;margin-top:20px;text-align:center;">
        Demo: admin@dentalhub.pro / demo123
      </p>
    </div>`;
  renderLoginForm();
}

function switchAuthTab(tab) {
  document.getElementById('tab-login').classList.toggle('active', tab === 'login');
  document.getElementById('tab-signup').classList.toggle('active', tab === 'signup');
  if (tab === 'login') renderLoginForm(); else renderSignupForm();
}

function renderLoginForm() {
  document.getElementById('auth-form').innerHTML = `
    <div class="form-group">
      <label class="form-label">Email Address</label>
      <div class="input-icon">
        <i class="fas fa-envelope"></i>
        <input type="email" id="login-email" class="form-input" placeholder="your@email.com" value="admin@dentalhub.pro"/>
      </div>
    </div>
    <div class="form-group">
      <label class="form-label">Password</label>
      <div class="input-icon">
        <i class="fas fa-lock"></i>
        <input type="password" id="login-password" class="form-input" placeholder="••••••••" value="demo123"/>
      </div>
    </div>
    <button class="btn btn-primary btn-full btn-lg" onclick="doLogin()">
      <i class="fas fa-sign-in-alt"></i> Login
    </button>
    <div style="text-align:center;margin-top:12px;font-size:12px;color:#64748b;">
      Finance: finance@dentalhub.pro / demo123
    </div>`;
}

function renderSignupForm() {
  document.getElementById('auth-form').innerHTML = `
    <p style="font-size:13px;color:#64748b;margin-bottom:16px;line-height:1.5;">
      Create two accounts: <b>Operational</b> (staff/technicians) & <b>Finance</b> (accountant/owner).
    </p>
    <div class="form-group">
      <label class="form-label">Lab Name</label>
      <input type="text" id="su-lab" class="form-input" placeholder="My Dental Lab"/>
    </div>
    <div style="background:#f0f7e6;border-radius:10px;padding:12px;margin-bottom:12px;">
      <div style="font-size:12px;font-weight:700;color:var(--primary);margin-bottom:8px;"><i class="fas fa-users"></i> Operational Account</div>
      <div class="form-group" style="margin-bottom:8px;">
        <input type="text" id="su-admin-name" class="form-input" placeholder="Admin Name"/>
      </div>
      <div class="form-group" style="margin-bottom:8px;">
        <input type="email" id="su-admin-email" class="form-input" placeholder="admin@lab.com"/>
      </div>
      <div class="form-group" style="margin-bottom:0;">
        <input type="password" id="su-admin-pass" class="form-input" placeholder="Password"/>
      </div>
    </div>
    <div style="background:#fff7ed;border-radius:10px;padding:12px;margin-bottom:16px;">
      <div style="font-size:12px;font-weight:700;color:#d97706;margin-bottom:8px;"><i class="fas fa-chart-line"></i> Finance Account</div>
      <div class="form-group" style="margin-bottom:8px;">
        <input type="text" id="su-fin-name" class="form-input" placeholder="Finance Manager Name"/>
      </div>
      <div class="form-group" style="margin-bottom:8px;">
        <input type="email" id="su-fin-email" class="form-input" placeholder="finance@lab.com"/>
      </div>
      <div class="form-group" style="margin-bottom:0;">
        <input type="password" id="su-fin-pass" class="form-input" placeholder="Password"/>
      </div>
    </div>
    <button class="btn btn-primary btn-full" onclick="doSignup()">
      <i class="fas fa-building"></i> Register Lab
    </button>`;
}

async function doLogin() {
  const email = document.getElementById('login-email').value.trim();
  const password = document.getElementById('login-password').value;
  if (!email || !password) { showToast('Please fill all fields', 'error'); return; }

  const result = await api.post('/auth/login', { email, password });
  if (result.success) {
    localStorage.setItem('dh_token', result.token);
    localStorage.setItem('dh_user', JSON.stringify(result.user));
    currentUser = result.user;
    showToast(`Welcome back, ${result.user.name}!`, 'success');
    initApp();
  } else {
    showToast(result.error || 'Login failed', 'error');
  }
}

async function doSignup() {
  const data = {
    lab_name: document.getElementById('su-lab').value.trim(),
    admin_name: document.getElementById('su-admin-name').value.trim(),
    admin_email: document.getElementById('su-admin-email').value.trim(),
    admin_password: document.getElementById('su-admin-pass').value,
    finance_name: document.getElementById('su-fin-name').value.trim(),
    finance_email: document.getElementById('su-fin-email').value.trim(),
    finance_password: document.getElementById('su-fin-pass').value,
  };
  const result = await api.post('/auth/signup', data);
  if (result.success) {
    showToast('Lab registered! Please login.', 'success');
    switchAuthTab('login');
  } else {
    showToast(result.error || 'Registration failed', 'error');
  }
}

async function doLogout() {
  await api.post('/auth/logout', {});
  localStorage.removeItem('dh_token');
  localStorage.removeItem('dh_user');
  currentUser = null;
  renderAuthPage();
}

// ===== APP INIT =====
function initApp() {
  if (currentUser.account_type === 'finance') {
    renderFinanceShell();
    navigateTo('fin-dashboard');
  } else {
    renderMainShell();
    navigateTo('dashboard');
  }
}

// ===== MAIN SHELL =====
function renderMainShell() {
  document.getElementById('app').innerHTML = `
    <div class="app-shell">
      <div class="app-header">
        <div class="logo">DentalHub <span>Pro</span></div>
        <button class="header-btn" onclick="toggleDark()" title="Toggle Dark Mode">
          <i class="fas fa-${darkMode?'sun':'moon'}"></i>
        </button>
        <button class="header-btn notification-badge" onclick="navigateTo('notifications')">
          <i class="fas fa-bell"></i>
          <span class="badge" id="notif-badge" style="display:none">0</span>
        </button>
        <button class="header-btn" onclick="showProfileMenu()">
          <span style="font-size:13px;font-weight:700">${getInitials(currentUser.name)}</span>
        </button>
      </div>
      <div class="page-content" id="page-content"></div>
      <button class="fab" id="main-fab" onclick="onFabClick()" title="Add Case">
        <i class="fas fa-plus"></i>
      </button>
      <nav class="bottom-nav" id="bottom-nav">
        <button class="nav-item" data-page="dashboard" onclick="navigateTo('dashboard')">
          <i class="fas fa-th-large"></i><span>Dashboard</span>
        </button>
        <button class="nav-item" data-page="cases" onclick="navigateTo('cases')">
          <i class="fas fa-folder-open"></i><span>Cases</span>
        </button>
        <button class="nav-item" data-page="clinics" onclick="navigateTo('clinics')">
          <i class="fas fa-clinic-medical"></i><span>Clinics</span>
        </button>
        <button class="nav-item" data-page="search" onclick="navigateTo('search')">
          <i class="fas fa-search"></i><span>Search</span>
        </button>
        <button class="nav-item" data-page="reports" onclick="navigateTo('reports')">
          <i class="fas fa-chart-bar"></i><span>Reports</span>
        </button>
      </nav>
    </div>`;
}

// ===== FINANCE SHELL =====
function renderFinanceShell() {
  document.getElementById('app').innerHTML = `
    <div class="app-shell">
      <div class="app-header">
        <div class="logo">DentalHub <span>Finance</span></div>
        <button class="header-btn" onclick="toggleDark()">
          <i class="fas fa-${darkMode?'sun':'moon'}"></i>
        </button>
        <button class="header-btn" onclick="showProfileMenu()">
          <span style="font-size:13px;font-weight:700">${getInitials(currentUser.name)}</span>
        </button>
      </div>
      <div class="page-content" id="page-content"></div>
      <nav class="bottom-nav" id="bottom-nav">
        <button class="nav-item" data-page="fin-dashboard" onclick="navigateTo('fin-dashboard')">
          <i class="fas fa-chart-pie"></i><span>Dashboard</span>
        </button>
        <button class="nav-item" data-page="invoices" onclick="navigateTo('invoices')">
          <i class="fas fa-file-invoice-dollar"></i><span>Invoices</span>
        </button>
        <button class="nav-item" data-page="payments" onclick="navigateTo('payments')">
          <i class="fas fa-credit-card"></i><span>Payments</span>
        </button>
        <button class="nav-item" data-page="profit" onclick="navigateTo('profit')">
          <i class="fas fa-trending-up"></i><span>Profit</span>
        </button>
      </nav>
    </div>`;
}

function toggleDark() {
  darkMode = !darkMode;
  document.documentElement.setAttribute('data-theme', darkMode ? 'dark' : 'light');
  localStorage.setItem('dh_dark', darkMode);
  document.querySelector('.header-btn i.fa-moon, .header-btn i.fa-sun').className = `fas fa-${darkMode?'sun':'moon'}`;
}

function setActiveNav(page) {
  document.querySelectorAll('.nav-item').forEach(el => {
    el.classList.toggle('active', el.dataset.page === page);
  });
}

function onFabClick() {
  showAddCaseModal();
}

// ===== NAVIGATION =====
async function navigateTo(page) {
  currentPage = page;
  setActiveNav(page);
  const fab = document.getElementById('main-fab');
  if (fab) fab.style.display = ['dashboard','cases'].includes(page) ? 'flex' : 'none';

  const content = document.getElementById('page-content');
  if (content) content.innerHTML = '<div class="loading"><div class="spinner"></div></div>';

  switch(page) {
    case 'dashboard': await renderDashboard(); break;
    case 'cases': await renderCasesPage(); break;
    case 'clinics': await renderClinicsPage(); break;
    case 'search': renderSearchPage(); break;
    case 'reports': await renderReportsPage(); break;
    case 'notifications': await renderNotificationsPage(); break;
    case 'fin-dashboard': await renderFinanceDashboard(); break;
    case 'invoices': await renderInvoicesPage(); break;
    case 'payments': await renderPaymentsPage(); break;
    case 'profit': await renderProfitPage(); break;
    default: content.innerHTML = '<div class="empty-state"><i class="fas fa-question-circle"></i><h3>Page not found</h3></div>';
  }
}

// ===== DASHBOARD =====
async function renderDashboard() {
  const content = document.getElementById('page-content');
  const [statsRes, casesRes] = await Promise.all([
    api.get('/cases/dashboard/stats'),
    api.get('/cases?limit=5')
  ]);

  const stats = statsRes.stats || {};
  const recentCases = casesRes.cases || [];

  const statusData = stats.by_status || [];
  const monthlyData = (stats.monthly || []).reverse();

  content.innerHTML = `
    <div class="fade-in">
      <!-- Greeting -->
      <div style="padding:16px 16px 8px;background:white;margin-bottom:2px;">
        <div style="font-size:13px;color:#64748b;">Good ${getGreeting()},</div>
        <div style="font-size:20px;font-weight:800;color:#1e293b;">${currentUser.name} <span style="font-size:14px;">👋</span></div>
      </div>

      <!-- Stats Grid -->
      <div class="stats-grid">
        <div class="stat-card" style="--accent:#76B82A">
          <div class="stat-icon" style="background:#f0f7e6;color:#76B82A"><i class="fas fa-folder-open"></i></div>
          <div class="stat-value">${stats.active || 0}</div>
          <div class="stat-label">Active Cases</div>
        </div>
        <div class="stat-card" style="--accent:#3b82f6">
          <div class="stat-icon" style="background:#eff6ff;color:#3b82f6"><i class="fas fa-cog"></i></div>
          <div class="stat-value">${(statusData.find(s=>s.status==='Milling')||{count:0}).count + (statusData.find(s=>s.status==='Printing')||{count:0}).count}</div>
          <div class="stat-label">In Production</div>
        </div>
        <div class="stat-card" style="--accent:#22c55e">
          <div class="stat-icon" style="background:#f0fdf4;color:#16a34a"><i class="fas fa-box"></i></div>
          <div class="stat-value">${stats.ready || 0}</div>
          <div class="stat-label">Ready Delivery</div>
        </div>
        <div class="stat-card" style="--accent:#ef4444">
          <div class="stat-icon" style="background:#fef2f2;color:#dc2626"><i class="fas fa-exclamation-triangle"></i></div>
          <div class="stat-value">${stats.delayed || 0}</div>
          <div class="stat-label">Delayed</div>
        </div>
      </div>

      <!-- Today's deliveries banner -->
      ${stats.today_deliveries > 0 ? `
      <div style="margin:0 16px 12px;background:linear-gradient(135deg,#76B82A,#5a9020);border-radius:12px;padding:14px;color:white;display:flex;align-items:center;gap:12px;">
        <div style="width:44px;height:44px;background:rgba(255,255,255,0.2);border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:20px;"><i class="fas fa-truck"></i></div>
        <div>
          <div style="font-weight:700;font-size:16px;">${stats.today_deliveries} Deliveries Today</div>
          <div style="font-size:12px;opacity:0.85;">Cases due for delivery today</div>
        </div>
        <button onclick="navigateTo('cases')" style="margin-left:auto;background:rgba(255,255,255,0.25);border:none;color:white;border-radius:8px;padding:8px 12px;font-size:12px;font-weight:700;cursor:pointer;">View</button>
      </div>` : ''}

      <!-- Monthly Chart -->
      ${monthlyData.length > 0 ? `
      <div class="chart-container">
        <div class="chart-title"><i class="fas fa-chart-bar text-primary"></i> Monthly Cases</div>
        <canvas id="monthly-chart" height="140"></canvas>
      </div>` : ''}

      <!-- Status Breakdown -->
      <div style="padding:8px 16px 4px;">
        <div class="section-title">Status Overview</div>
      </div>
      <div style="padding:0 16px;display:flex;flex-wrap:wrap;gap:8px;margin-bottom:16px;">
        ${statusData.map(s => `
          <div onclick="filterCasesByStatus('${s.status}')" style="background:white;border-radius:10px;padding:10px 14px;display:flex;align-items:center;gap:8px;cursor:pointer;box-shadow:0 1px 4px rgba(0,0,0,0.06);">
            ${statusBadge(s.status)}
            <span style="font-weight:700;font-size:16px;">${s.count}</span>
          </div>`).join('')}
      </div>

      <!-- Recent Cases -->
      <div class="section-header">
        <div class="section-title">Recent Cases</div>
        <button onclick="navigateTo('cases')" class="section-link">See All →</button>
      </div>
      ${recentCases.length ? recentCases.map(c => renderCaseCard(c)).join('') : '<div class="empty-state"><i class="fas fa-folder-open"></i><h3>No cases yet</h3><p>Tap + to create your first case</p></div>'}
    </div>`;

  // Draw chart
  if (monthlyData.length > 0) {
    setTimeout(() => {
      const ctx = document.getElementById('monthly-chart');
      if (ctx) {
        new Chart(ctx, {
          type: 'bar',
          data: {
            labels: monthlyData.map(m => m.month),
            datasets: [{
              data: monthlyData.map(m => m.count),
              backgroundColor: 'rgba(118,184,42,0.7)',
              borderColor: '#76B82A',
              borderWidth: 2,
              borderRadius: 6
            }]
          },
          options: {
            responsive: true, plugins: { legend: { display: false } },
            scales: { y: { beginAtZero: true, ticks: { stepSize: 1 } } }
          }
        });
      }
    }, 100);
  }
}

function getGreeting() {
  const h = new Date().getHours();
  return h < 12 ? 'Morning' : h < 17 ? 'Afternoon' : 'Evening';
}

function filterCasesByStatus(status) {
  navigateTo('cases');
  setTimeout(() => { window.__filterStatus = status; renderCasesPage(status); }, 100);
}


// ===== CASES PAGE =====
async function renderCasesPage(filterStatus = null) {
  const content = document.getElementById('page-content');
  const status = filterStatus || window.__filterStatus || '';
  const res = await api.get(`/cases?${status ? 'status='+encodeURIComponent(status) : ''}&limit=100`);
  allCases = res.cases || [];

  const statuses = ['All','Received','In Design','Milling','Printing','Finishing','Quality Check','Ready for Delivery','Completed','On Hold','Remake'];

  content.innerHTML = `
    <div class="fade-in">
      <div class="search-bar">
        <div class="search-input-wrap">
          <i class="fas fa-search"></i>
          <input type="text" id="cases-search" placeholder="Search cases, patients..." oninput="filterCases()" />
        </div>
      </div>
      <div class="filter-chips" id="status-chips">
        ${statuses.map(s => `
          <button class="chip ${(s==='All'&&!status)||(s===status)?'active':''}" onclick="selectStatusFilter('${s}')">${s}</button>
        `).join('')}
      </div>
      <div id="cases-list">
        ${allCases.length ? allCases.map(c => renderCaseCard(c)).join('') :
          '<div class="empty-state"><i class="fas fa-folder-open"></i><h3>No cases found</h3><p>Tap the + button to add a new case</p></div>'}
      </div>
    </div>`;
}

function selectStatusFilter(status) {
  window.__filterStatus = status === 'All' ? '' : status;
  renderCasesPage(window.__filterStatus);
}

function filterCases() {
  const q = document.getElementById('cases-search')?.value.toLowerCase() || '';
  const filtered = q ? allCases.filter(c =>
    c.patient_name?.toLowerCase().includes(q) ||
    c.case_number?.toLowerCase().includes(q) ||
    c.clinic_name?.toLowerCase().includes(q) ||
    c.dentist_name?.toLowerCase().includes(q)
  ) : allCases;
  const list = document.getElementById('cases-list');
  if (list) list.innerHTML = filtered.length ? filtered.map(c => renderCaseCard(c)).join('') :
    '<div class="empty-state"><i class="fas fa-search"></i><h3>No results</h3></div>';
}

function renderCaseCard(c) {
  const isDelayed = c.expected_delivery_date && new Date(c.expected_delivery_date) < new Date() && !['Completed','Cancelled'].includes(c.status);
  const borderColor = isDelayed ? '#ef4444' : (STATUS_MAP[c.status]?.icon === 'fa-check-circle' ? '#76B82A' : '#e2e8f0');
  return `
    <div class="case-card" onclick="openCase(${c.id})" style="border-left-color:${borderColor}">
      <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:4px;">
        <div class="case-number">#${c.case_number}</div>
        <div style="display:flex;gap:4px;">${statusBadge(c.status)}</div>
      </div>
      <div class="patient-name">${c.patient_name}</div>
      <div class="case-meta">
        ${c.clinic_name ? `<span><i class="fas fa-clinic-medical"></i>${c.clinic_name}</span>` : ''}
        ${c.dentist_name ? `<span><i class="fas fa-user-md"></i>${c.dentist_name}</span>` : ''}
        ${c.expected_delivery_date ? `<span style="color:${isDelayed?'#dc2626':'#64748b'}"><i class="fas fa-calendar-check"></i>${formatDate(c.expected_delivery_date)}</span>` : ''}
      </div>
      <div style="display:flex;justify-content:space-between;align-items:center;">
        ${priorityBadge(c.priority || 'Normal')}
        <div style="display:flex;gap:10px;font-size:11px;color:#94a3b8;">
          ${c.file_count > 0 ? `<span><i class="fas fa-paperclip"></i> ${c.file_count}</span>` : ''}
          ${c.note_count > 0 ? `<span><i class="fas fa-comment"></i> ${c.note_count}</span>` : ''}
          <span>${timeAgo(c.creation_date)}</span>
        </div>
      </div>
    </div>`;
}

// ===== CASE DETAIL =====
async function openCase(caseId) {
  const content = document.getElementById('page-content');
  content.innerHTML = '<div class="loading"><div class="spinner"></div></div>';

  const res = await api.get(`/cases/${caseId}`);
  if (res.error) { showToast(res.error, 'error'); return; }

  const c = res.case;
  const procs = res.procedures || [];
  const tracking = res.tracking || [];
  const notes = res.notes || [];
  const files = res.files || [];
  const isDelayed = c.expected_delivery_date && new Date(c.expected_delivery_date) < new Date() && !['Completed','Cancelled'].includes(c.status);

  const canEdit = ['admin','case_manager','technician'].includes(currentUser.role);

  content.innerHTML = `
    <div class="fade-in">
      <!-- Back button -->
      <div style="padding:12px 16px;background:white;border-bottom:1px solid #f1f5f9;display:flex;align-items:center;gap:10px;">
        <button onclick="navigateTo('cases')" class="btn btn-ghost btn-sm"><i class="fas fa-arrow-left"></i></button>
        <div style="flex:1;">
          <div style="font-size:11px;color:#76B82A;font-weight:700;">#${c.case_number}</div>
          <div style="font-size:16px;font-weight:700;">${c.patient_name}</div>
        </div>
        ${canEdit ? `<button onclick="showStatusUpdateModal(${c.id},'${c.status}')" class="btn btn-primary btn-sm"><i class="fas fa-sync-alt"></i> Update</button>` : ''}
      </div>

      <!-- Status Banner -->
      <div style="background:white;padding:12px 16px;border-bottom:1px solid #f1f5f9;display:flex;align-items:center;justify-content:space-between;">
        ${statusBadge(c.status)}
        ${priorityBadge(c.priority || 'Normal')}
        ${isDelayed ? '<span class="badge badge-delayed"><i class="fas fa-exclamation-triangle"></i>Delayed</span>' : ''}
      </div>

      <!-- Case Info -->
      <div class="card" style="margin:12px 16px 0;">
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
          ${renderInfoField('Clinic', c.clinic_name, 'fa-clinic-medical')}
          ${renderInfoField('Dentist', c.dentist_name, 'fa-user-md')}
          ${renderInfoField('Technician', c.technician_name, 'fa-tools')}
          ${renderInfoField('Appointment', formatDate(c.appointment_date), 'fa-calendar')}
          ${renderInfoField('Expected Delivery', formatDate(c.expected_delivery_date), 'fa-calendar-check', isDelayed ? '#dc2626' : null)}
          ${renderInfoField('Created', formatDate(c.creation_date), 'fa-clock')}
          ${c.shade ? renderInfoField('Shade', c.shade, 'fa-palette') : ''}
          ${c.arch ? renderInfoField('Arch', c.arch, 'fa-tooth') : ''}
        </div>
        ${c.notes ? `<div style="margin-top:12px;padding:10px;background:#f8fafc;border-radius:8px;font-size:13px;color:#475569;"><i class="fas fa-sticky-note" style="color:#76B82A;margin-right:6px;"></i>${c.notes}</div>` : ''}
      </div>

      <!-- Procedures -->
      ${procs.length ? `
      <div style="padding:12px 16px 4px;"><div class="section-title"><i class="fas fa-list-ul" style="color:#76B82A;margin-right:6px;"></i>Procedures</div></div>
      <div class="card" style="margin:0 16px;">
        ${procs.map(p => `
          <div style="display:flex;justify-content:space-between;align-items:center;padding:8px 0;border-bottom:1px solid #f1f5f9;">
            <div>
              <div style="font-weight:600;font-size:14px;">${p.procedure_name}</div>
              ${p.notes ? `<div style="font-size:11px;color:#64748b;">${p.notes}</div>` : ''}
            </div>
            <div style="text-align:right;">
              <div style="font-size:12px;color:#64748b;">x${p.quantity}</div>
              ${p.unit_price > 0 ? `<div style="font-weight:700;color:#76B82A;">$${(p.unit_price * p.quantity).toFixed(2)}</div>` : ''}
            </div>
          </div>`).join('')}
      </div>` : ''}

      <!-- Tabs: Tracking | Notes | Files | Logistics -->
      <div style="margin-top:12px;">
        <div class="tabs">
          <button class="tab active" id="tab-track" onclick="showCaseTab('track',${c.id})"><i class="fas fa-map-marker-alt"></i> Tracking</button>
          <button class="tab" id="tab-notes" onclick="showCaseTab('notes',${c.id})"><i class="fas fa-comments"></i> Notes ${notes.length ? `(${notes.length})` : ''}</button>
          <button class="tab" id="tab-files" onclick="showCaseTab('files',${c.id})"><i class="fas fa-paperclip"></i> Files ${files.length ? `(${files.length})` : ''}</button>
          <button class="tab" id="tab-logistics" onclick="showCaseTab('logistics',${c.id})"><i class="fas fa-truck"></i> Delivery</button>
        </div>
        <div id="case-tab-content">
          ${renderTrackingTab(tracking)}
        </div>
      </div>

      <!-- Action Pills -->
      <div style="padding:16px;">
        <div class="action-pills">
          <button class="pill pill-primary" onclick="showAddNoteModal(${c.id})"><i class="fas fa-comment-plus"></i> Add Note</button>
          <button class="pill pill-info" onclick="showUploadFileModal(${c.id})"><i class="fas fa-upload"></i> Upload File</button>
          <button class="pill pill-warning" onclick="printWorkTicket(${c.id})"><i class="fas fa-print"></i> Work Ticket</button>
          ${canEdit ? `<button class="pill pill-primary" onclick="cloneCase(${c.id})"><i class="fas fa-copy"></i> Clone</button>` : ''}
          ${c.status !== 'Completed' && canEdit ? `<button class="pill pill-danger" onclick="confirmCancelCase(${c.id})"><i class="fas fa-ban"></i> Cancel</button>` : ''}
        </div>
      </div>

      <!-- Logistics info if set -->
      ${c.courier ? `
      <div class="card" style="margin:0 16px 16px;background:#f0f7e6;">
        <div style="font-weight:700;font-size:13px;color:#76B82A;margin-bottom:8px;"><i class="fas fa-truck"></i> Shipping</div>
        <div style="font-size:13px;color:#475569;">${c.courier} — <b>${c.tracking_number || 'No tracking #'}</b></div>
        ${c.dispatch_date ? `<div style="font-size:12px;color:#64748b;margin-top:4px;">Dispatched: ${formatDate(c.dispatch_date)}</div>` : ''}
      </div>` : ''}
    </div>`;

  // Store for tab use
  window.__caseTabData = { tracking, notes, files, caseId: c.id, courierId: c.id, courier: c.courier, tracking_number: c.tracking_number };
}

function renderInfoField(label, value, icon, color = null) {
  return `<div>
    <div style="font-size:10px;text-transform:uppercase;letter-spacing:0.5px;color:#94a3b8;font-weight:700;margin-bottom:3px;">${label}</div>
    <div style="font-size:14px;font-weight:600;color:${color||'#1e293b'};display:flex;align-items:center;gap:5px;">
      <i class="fas ${icon}" style="color:#76B82A;font-size:12px;"></i>${value || '—'}
    </div>
  </div>`;
}

function renderTrackingTab(tracking) {
  if (!tracking.length) return '<div class="empty-state" style="padding:24px"><i class="fas fa-map-marker-alt"></i><p>No tracking yet</p></div>';
  return `<div class="tracking-timeline">${tracking.map((t, i) => `
    <div class="tracking-item">
      <div class="tracking-dot ${i === 0 ? 'current' : 'completed'}">
        <i class="fas ${STATUS_MAP[t.status]?.icon || 'fa-circle'}" style="font-size:14px;"></i>
      </div>
      <div class="tracking-content">
        <div class="tracking-status">${t.status}</div>
        ${t.note ? `<div class="tracking-detail">${t.note}</div>` : ''}
        <div class="tracking-time">${t.technician_name || ''} • ${formatDate(t.created_at)} ${new Date(t.created_at).toLocaleTimeString('en', {hour:'2-digit',minute:'2-digit'})}</div>
      </div>
    </div>`).join('')}</div>`;
}

function showCaseTab(tab, caseId) {
  document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
  document.getElementById('tab-' + tab)?.classList.add('active');
  const data = window.__caseTabData || {};
  const container = document.getElementById('case-tab-content');

  if (tab === 'track') {
    container.innerHTML = renderTrackingTab(data.tracking || []);
  } else if (tab === 'notes') {
    const notes = data.notes || [];
    container.innerHTML = `
      <div class="chat-container">
        ${notes.length ? notes.map(n => `
          <div class="chat-message ${n.user_id === currentUser.id ? 'sent' : 'received'}">
            ${n.user_id !== currentUser.id ? `<div class="sender">${n.user_name} • ${n.user_role}</div>` : ''}
            <div>${n.message}</div>
            <div class="time">${new Date(n.created_at).toLocaleTimeString('en', {hour:'2-digit',minute:'2-digit'})}</div>
          </div>`).join('') : '<div class="empty-state" style="padding:24px"><i class="fas fa-comments"></i><p>No notes yet</p></div>'}
      </div>
      <div style="padding:12px 16px;background:white;border-top:1px solid #f1f5f9;display:flex;gap:8px;">
        <input type="text" id="note-input" class="form-input" placeholder="Type a note..." style="flex:1;padding:10px 14px;"/>
        <button onclick="quickAddNote(${caseId})" class="btn btn-primary btn-sm"><i class="fas fa-paper-plane"></i></button>
      </div>`;
  } else if (tab === 'files') {
    const files = data.files || [];
    container.innerHTML = `
      <div style="padding:16px;">
        ${files.length ? `<div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;">${files.map(f => `
          <div style="background:white;border-radius:10px;padding:12px;box-shadow:0 1px 4px rgba(0,0,0,0.06);">
            <div style="font-size:24px;text-align:center;margin-bottom:6px;">${getFileIcon(f.file_type)}</div>
            <div style="font-size:11px;font-weight:600;color:#1e293b;text-align:center;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${f.file_name}</div>
            <div style="font-size:10px;color:#94a3b8;text-align:center;margin-top:2px;">${f.uploaded_by_name}</div>
          </div>`).join('')}</div>` :
          '<div class="empty-state" style="padding:24px"><i class="fas fa-paperclip"></i><p>No files attached</p></div>'}
        <button onclick="showUploadFileModal(${caseId})" class="btn btn-outline btn-full" style="margin-top:12px;"><i class="fas fa-upload"></i> Upload File</button>
      </div>`;
  } else if (tab === 'logistics') {
    container.innerHTML = `
      <div style="padding:16px;">
        <div class="form-group"><label class="form-label">Courier</label>
          <select id="log-courier" class="form-select">
            <option value="">Select Courier</option>
            <option value="FedEx">FedEx</option><option value="DHL">DHL</option>
            <option value="UPS">UPS</option><option value="Local Courier">Local Courier</option>
          </select>
        </div>
        <div class="form-group"><label class="form-label">Tracking Number</label>
          <input type="text" id="log-tracking" class="form-input" placeholder="e.g. 123456789" value="${data.tracking_number||''}"/>
        </div>
        <div class="form-group"><label class="form-label">Dispatch Date</label>
          <input type="date" id="log-dispatch" class="form-input"/>
        </div>
        <button onclick="saveLogistics(${caseId})" class="btn btn-primary btn-full"><i class="fas fa-save"></i> Save Logistics</button>
      </div>`;
    if (data.courier) document.getElementById('log-courier').value = data.courier;
  }
}

async function quickAddNote(caseId) {
  const input = document.getElementById('note-input');
  const msg = input?.value.trim();
  if (!msg) return;
  const res = await api.post(`/cases/${caseId}/notes`, { message: msg });
  if (res.success) {
    input.value = '';
    const caseRes = await api.get(`/cases/${caseId}`);
    if (window.__caseTabData) window.__caseTabData.notes = caseRes.notes || [];
    showCaseTab('notes', caseId);
    showToast('Note added', 'success');
  }
}

async function saveLogistics(caseId) {
  const courier = document.getElementById('log-courier')?.value;
  const tracking = document.getElementById('log-tracking')?.value;
  const dispatch = document.getElementById('log-dispatch')?.value;
  await api.put(`/cases/${caseId}`, { courier, tracking_number: tracking, dispatch_date: dispatch });
  showToast('Logistics saved!', 'success');
}

function getFileIcon(type) {
  if (!type) return '📄';
  if (type.includes('image')) return '🖼️';
  if (type === 'stl') return '🦷';
  if (type === 'pdf') return '📋';
  return '📁';
}


// ===== ADD CASE MODAL =====
async function showAddCaseModal() {
  // Preload data
  const [clinicsRes, dentistsRes, techRes, procsRes] = await Promise.all([
    api.get('/clinics'), api.get('/dentists'), api.get('/users/technicians'), api.get('/procedures')
  ]);
  allClinics = clinicsRes.clinics || [];
  allDentists = dentistsRes.dentists || [];
  technicians = techRes.technicians || [];
  allProcedures = procsRes.procedures || [];
  caseProcedures = [];

  const today = new Date().toISOString().split('T')[0];
  const nextWeek = new Date(Date.now() + 7*86400000).toISOString().split('T')[0];

  showModal('add-case-modal', `
    <div class="modal-handle"></div>
    <div class="modal-title"><i class="fas fa-folder-plus text-primary"></i> New Case</div>
    
    <div class="form-group">
      <label class="form-label">Patient Name *</label>
      <input type="text" id="nc-patient" class="form-input" placeholder="Full patient name"/>
    </div>
    <div class="form-group">
      <label class="form-label">Clinic</label>
      <select id="nc-clinic" class="form-select" onchange="loadDentistsByClinic(this.value)">
        <option value="">— Select Clinic —</option>
        ${allClinics.map(c => `<option value="${c.id}">${c.name}</option>`).join('')}
      </select>
    </div>
    <div class="form-group">
      <label class="form-label">Dentist</label>
      <select id="nc-dentist" class="form-select">
        <option value="">— Select Dentist —</option>
        ${allDentists.map(d => `<option value="${d.id}">${d.name}</option>`).join('')}
      </select>
    </div>
    <div class="form-group">
      <label class="form-label">Assign Technician</label>
      <select id="nc-tech" class="form-select">
        <option value="">— Unassigned —</option>
        ${technicians.map(t => `<option value="${t.id}">${t.name} (${t.role})</option>`).join('')}
      </select>
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
      <div class="form-group">
        <label class="form-label">Appointment Date</label>
        <input type="date" id="nc-appt" class="form-input" value="${today}"/>
      </div>
      <div class="form-group">
        <label class="form-label">Expected Delivery</label>
        <input type="date" id="nc-delivery" class="form-input" value="${nextWeek}"/>
      </div>
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
      <div class="form-group">
        <label class="form-label">Priority</label>
        <select id="nc-priority" class="form-select">
          <option>Normal</option><option>High</option><option>Urgent</option><option>Low</option>
        </select>
      </div>
      <div class="form-group">
        <label class="form-label">Arch</label>
        <select id="nc-arch" class="form-select">
          <option value="">—</option><option>Upper</option><option>Lower</option>
          <option>Both</option><option>N/A</option>
        </select>
      </div>
    </div>
    <div class="form-group">
      <label class="form-label">Shade</label>
      <input type="text" id="nc-shade" class="form-input" placeholder="e.g. A2, BL1..."/>
    </div>

    <!-- Procedures section -->
    <div style="margin-bottom:8px;">
      <div style="font-size:12px;font-weight:700;text-transform:uppercase;color:#475569;letter-spacing:0.5px;margin-bottom:8px;">Procedures</div>
      <div id="procedure-list"></div>
      <button onclick="addProcedureRow()" class="btn btn-outline btn-sm btn-full" style="margin-top:4px;">
        <i class="fas fa-plus"></i> Add Procedure
      </button>
    </div>

    <div class="form-group">
      <label class="form-label">Notes</label>
      <textarea id="nc-notes" class="form-textarea" placeholder="Additional notes..."></textarea>
    </div>

    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:8px;">
      <button onclick="closeModal('add-case-modal')" class="btn btn-ghost">Cancel</button>
      <button onclick="submitNewCase()" class="btn btn-primary"><i class="fas fa-save"></i> Create Case</button>
    </div>
  `);
}

function addProcedureRow() {
  const list = document.getElementById('procedure-list');
  const idx = caseProcedures.length;
  caseProcedures.push({ procedure_id: '', procedure_name: '', quantity: 1, unit_price: 0 });
  const row = document.createElement('div');
  row.id = `proc-row-${idx}`;
  row.style.cssText = 'display:grid;grid-template-columns:1fr auto auto auto;gap:6px;margin-bottom:6px;align-items:center;';
  row.innerHTML = `
    <select class="form-select" style="padding:8px;" onchange="onProcSelect(this,${idx})">
      <option value="">Select procedure</option>
      ${allProcedures.map(p => `<option value="${p.id}" data-price="${p.base_price}" data-name="${p.name}">${p.name}</option>`).join('')}
      <option value="custom">+ Custom</option>
    </select>
    <input type="number" class="form-input" style="padding:8px;width:56px;" placeholder="Qty" value="1"
      oninput="caseProcedures[${idx}].quantity=parseInt(this.value)||1"/>
    <input type="number" class="form-input" style="padding:8px;width:72px;" id="proc-price-${idx}" placeholder="$" value="0"
      oninput="caseProcedures[${idx}].unit_price=parseFloat(this.value)||0"/>
    <button onclick="removeProcRow(${idx})" class="btn btn-ghost btn-sm" style="color:#ef4444;padding:8px;"><i class="fas fa-times"></i></button>`;
  list.appendChild(row);
}

function onProcSelect(sel, idx) {
  const opt = sel.options[sel.selectedIndex];
  if (opt.value === 'custom') {
    const name = prompt('Enter procedure name:');
    if (name) { caseProcedures[idx].procedure_name = name; caseProcedures[idx].procedure_id = null; }
  } else {
    caseProcedures[idx].procedure_id = parseInt(opt.value) || null;
    caseProcedures[idx].procedure_name = opt.dataset.name || opt.text;
    caseProcedures[idx].unit_price = parseFloat(opt.dataset.price) || 0;
    const priceEl = document.getElementById(`proc-price-${idx}`);
    if (priceEl) priceEl.value = caseProcedures[idx].unit_price;
  }
}

function removeProcRow(idx) {
  document.getElementById(`proc-row-${idx}`)?.remove();
  caseProcedures[idx] = null;
}

function loadDentistsByClinic(clinicId) {
  const sel = document.getElementById('nc-dentist');
  if (!sel) return;
  const filtered = clinicId ? allDentists.filter(d => d.clinic_id == clinicId) : allDentists;
  sel.innerHTML = '<option value="">— Select Dentist —</option>' +
    filtered.map(d => `<option value="${d.id}">${d.name}</option>`).join('');
}

async function submitNewCase() {
  const patient = document.getElementById('nc-patient')?.value.trim();
  if (!patient) { showToast('Patient name required', 'error'); return; }

  const validProcs = caseProcedures.filter(p => p && p.procedure_name);
  const data = {
    patient_name: patient,
    clinic_id: document.getElementById('nc-clinic')?.value || null,
    dentist_id: document.getElementById('nc-dentist')?.value || null,
    assigned_technician_id: document.getElementById('nc-tech')?.value || null,
    appointment_date: document.getElementById('nc-appt')?.value || null,
    expected_delivery_date: document.getElementById('nc-delivery')?.value || null,
    priority: document.getElementById('nc-priority')?.value || 'Normal',
    arch: document.getElementById('nc-arch')?.value || null,
    shade: document.getElementById('nc-shade')?.value || null,
    notes: document.getElementById('nc-notes')?.value || null,
    procedures: validProcs
  };

  const res = await api.post('/cases', data);
  if (res.success) {
    closeModal('add-case-modal');
    showToast(`Case #${res.case_number} created!`, 'success');
    navigateTo('cases');
  } else {
    showToast(res.error || 'Failed to create case', 'error');
  }
}

// ===== STATUS UPDATE MODAL =====
function showStatusUpdateModal(caseId, currentStatus) {
  const statuses = ['Received','In Design','Milling','Printing','Finishing','Quality Check','Ready for Delivery','Completed','On Hold','Remake'];
  showModal('status-modal', `
    <div class="modal-handle"></div>
    <div class="modal-title"><i class="fas fa-sync-alt text-primary"></i> Update Status</div>
    <div style="display:grid;gap:8px;margin-bottom:16px;">
      ${statuses.map(s => `
        <button onclick="selectStatus('${s}')" id="st-${s.replace(/\s/g,'')}" 
          class="btn ${s === currentStatus ? 'btn-primary' : 'btn-ghost'}" 
          style="justify-content:flex-start;text-align:left;padding:12px 16px;">
          <i class="fas ${STATUS_MAP[s]?.icon||'fa-circle'}" style="width:20px;"></i>${s}
          ${s === currentStatus ? '<i class="fas fa-check" style="margin-left:auto;"></i>' : ''}
        </button>`).join('')}
    </div>
    <div class="form-group">
      <label class="form-label">Status Note</label>
      <input type="text" id="status-note" class="form-input" placeholder="e.g. Milling completed, ready for polishing"/>
    </div>
    <button onclick="submitStatusUpdate(${caseId})" class="btn btn-primary btn-full"><i class="fas fa-save"></i> Update Status</button>
  `);
}

let selectedStatus = '';
function selectStatus(status) {
  selectedStatus = status;
  document.querySelectorAll('[id^="st-"]').forEach(btn => {
    const s = btn.id.slice(3).replace(/([A-Z])/g, ' $1').trim();
    btn.className = 'btn ' + (btn.id === 'st-' + status.replace(/\s/g,'') ? 'btn-primary' : 'btn-ghost');
  });
}

async function submitStatusUpdate(caseId) {
  if (!selectedStatus) { showToast('Please select a status', 'warning'); return; }
  const note = document.getElementById('status-note')?.value;
  const res = await api.put(`/cases/${caseId}`, { status: selectedStatus, status_note: note });
  if (res.success) {
    closeModal('status-modal');
    showToast(`Status updated to: ${selectedStatus}`, 'success');
    openCase(caseId);
  } else {
    showToast(res.error || 'Update failed', 'error');
  }
}

// ===== ADD NOTE MODAL =====
function showAddNoteModal(caseId) {
  showModal('note-modal', `
    <div class="modal-handle"></div>
    <div class="modal-title"><i class="fas fa-comment-plus text-primary"></i> Add Note</div>
    <div class="form-group">
      <textarea id="modal-note" class="form-textarea" placeholder="Write your note here..." rows="5" style="min-height:120px;"></textarea>
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;">
      <button onclick="closeModal('note-modal')" class="btn btn-ghost">Cancel</button>
      <button onclick="submitNote(${caseId})" class="btn btn-primary"><i class="fas fa-paper-plane"></i> Send</button>
    </div>
  `);
}

async function submitNote(caseId) {
  const msg = document.getElementById('modal-note')?.value.trim();
  if (!msg) { showToast('Note cannot be empty', 'error'); return; }
  const res = await api.post(`/cases/${caseId}/notes`, { message: msg });
  if (res.success) {
    closeModal('note-modal');
    showToast('Note added!', 'success');
    openCase(caseId);
  }
}

// ===== UPLOAD FILE MODAL =====
function showUploadFileModal(caseId) {
  showModal('file-modal', `
    <div class="modal-handle"></div>
    <div class="modal-title"><i class="fas fa-upload text-primary"></i> Upload File</div>
    <div style="border:2px dashed #76B82A;border-radius:12px;padding:24px;text-align:center;margin-bottom:16px;background:#f0f7e6;">
      <i class="fas fa-cloud-upload-alt" style="font-size:32px;color:#76B82A;margin-bottom:8px;"></i>
      <p style="font-size:13px;color:#64748b;margin:0;">Select file to attach</p>
    </div>
    <div class="form-group">
      <label class="form-label">File Name</label>
      <input type="text" id="file-name" class="form-input" placeholder="e.g. patient_scan.stl"/>
    </div>
    <div class="form-group">
      <label class="form-label">File Type</label>
      <select id="file-type" class="form-select">
        <option value="stl">STL File</option><option value="cbct">CBCT Scan</option>
        <option value="image">Patient Photo</option><option value="screenshot">Design Screenshot</option>
        <option value="pdf">PDF</option><option value="other">Other</option>
      </select>
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;">
      <button onclick="closeModal('file-modal')" class="btn btn-ghost">Cancel</button>
      <button onclick="submitFile(${caseId})" class="btn btn-primary"><i class="fas fa-save"></i> Attach</button>
    </div>
  `);
}

async function submitFile(caseId) {
  const name = document.getElementById('file-name')?.value.trim();
  const type = document.getElementById('file-type')?.value;
  if (!name) { showToast('File name required', 'error'); return; }
  const res = await api.post(`/cases/${caseId}/files`, { file_name: name, file_type: type, file_url: '#' });
  if (res.success) {
    closeModal('file-modal');
    showToast('File attached!', 'success');
    openCase(caseId);
  }
}

// ===== PRINT WORK TICKET =====
async function printWorkTicket(caseId) {
  const res = await api.get(`/cases/${caseId}`);
  if (!res.case) return;
  const c = res.case;
  const procs = res.procedures || [];
  const ticket = window.open('', '_blank', 'width=600,height=800');
  ticket.document.write(`<!DOCTYPE html><html><head><title>Work Ticket #${c.case_number}</title>
    <style>body{font-family:Arial,sans-serif;padding:20px;max-width:600px;margin:0 auto;}
    .header{text-align:center;border-bottom:3px solid #76B82A;padding-bottom:16px;margin-bottom:20px;}
    h1{color:#76B82A;font-size:20px;}table{width:100%;border-collapse:collapse;}
    td{padding:8px;border-bottom:1px solid #eee;}td:first-child{font-weight:bold;color:#475569;width:40%;}
    .badge{background:#76B82A;color:white;padding:4px 10px;border-radius:20px;font-size:12px;}
    .procs{margin-top:20px;}
    @media print{button{display:none}}</style></head><body>
    <div class="header">
      <h1>🦷 DentalHub Pro — Work Ticket</h1>
      <div style="font-size:24px;font-weight:bold;color:#76B82A">#${c.case_number}</div>
    </div>
    <table>
      <tr><td>Patient</td><td><strong>${c.patient_name}</strong></td></tr>
      <tr><td>Clinic</td><td>${c.clinic_name||'—'}</td></tr>
      <tr><td>Dentist</td><td>${c.dentist_name||'—'}</td></tr>
      <tr><td>Technician</td><td>${c.technician_name||'—'}</td></tr>
      <tr><td>Appointment</td><td>${formatDate(c.appointment_date)}</td></tr>
      <tr><td>Expected Delivery</td><td>${formatDate(c.expected_delivery_date)}</td></tr>
      <tr><td>Status</td><td><span class="badge">${c.status}</span></td></tr>
      <tr><td>Priority</td><td>${c.priority||'Normal'}</td></tr>
      ${c.shade ? `<tr><td>Shade</td><td>${c.shade}</td></tr>` : ''}
      ${c.arch ? `<tr><td>Arch</td><td>${c.arch}</td></tr>` : ''}
    </table>
    ${procs.length ? `<div class="procs"><h3>Procedures:</h3>
      ${procs.map(p => `<div style="padding:8px;border:1px solid #eee;border-radius:6px;margin-bottom:6px;">
        <strong>${p.procedure_name}</strong> × ${p.quantity} ${p.notes ? `<br><small>${p.notes}</small>` : ''}
      </div>`).join('')}</div>` : ''}
    ${c.notes ? `<div style="margin-top:20px;padding:12px;background:#f0f7e6;border-radius:8px;"><strong>Notes:</strong> ${c.notes}</div>` : ''}
    <div style="margin-top:30px;border-top:1px solid #eee;padding-top:16px;font-size:12px;color:#94a3b8;text-align:center;">
      Generated by DentalHub Pro • ${new Date().toLocaleString()}
    </div>
    <button onclick="window.print()" style="margin-top:20px;padding:10px 20px;background:#76B82A;color:white;border:none;border-radius:8px;cursor:pointer;font-size:14px;">Print</button>
    </body></html>`);
  ticket.document.close();
}

async function cloneCase(caseId) {
  const res = await api.get(`/cases/${caseId}`);
  if (!res.case) return;
  const c = res.case;
  const newCase = {
    patient_name: c.patient_name + ' (Copy)',
    clinic_id: c.clinic_id, dentist_id: c.dentist_id,
    assigned_technician_id: c.assigned_technician_id,
    priority: c.priority, shade: c.shade, arch: c.arch, notes: c.notes,
    procedures: (res.procedures||[]).map(p => ({ procedure_id: p.procedure_id, procedure_name: p.procedure_name, quantity: p.quantity, unit_price: p.unit_price }))
  };
  const result = await api.post('/cases', newCase);
  if (result.success) {
    showToast(`Case cloned as #${result.case_number}`, 'success');
    navigateTo('cases');
  }
}

async function confirmCancelCase(caseId) {
  if (!confirm('Cancel this case?')) return;
  await api.del(`/cases/${caseId}`);
  showToast('Case cancelled', 'warning');
  navigateTo('cases');
}


// ===== CLINICS PAGE =====
async function renderClinicsPage() {
  const content = document.getElementById('page-content');
  const res = await api.get('/clinics');
  allClinics = res.clinics || [];

  content.innerHTML = `
    <div class="fade-in">
      <div class="search-bar">
        <div class="search-input-wrap">
          <i class="fas fa-search"></i>
          <input type="text" id="clinic-search" placeholder="Search clinics..." oninput="filterClinics()"/>
        </div>
      </div>
      <div style="padding:8px 16px;display:flex;justify-content:flex-end;">
        <button onclick="showAddClinicModal()" class="btn btn-primary btn-sm"><i class="fas fa-plus"></i> Add Clinic</button>
      </div>
      <div id="clinics-list">
        ${allClinics.length ? allClinics.map(renderClinicItem).join('') : '<div class="empty-state"><i class="fas fa-clinic-medical"></i><h3>No clinics yet</h3></div>'}
      </div>
    </div>`;
}

function filterClinics() {
  const q = document.getElementById('clinic-search')?.value.toLowerCase() || '';
  const filtered = q ? allClinics.filter(c => c.name.toLowerCase().includes(q) || (c.city||'').toLowerCase().includes(q)) : allClinics;
  document.getElementById('clinics-list').innerHTML = filtered.length ? filtered.map(renderClinicItem).join('') : '<div class="empty-state"><i class="fas fa-search"></i><h3>No results</h3></div>';
}

function renderClinicItem(c) {
  return `
    <div class="list-item" onclick="openClinic(${c.id})">
      <div class="list-avatar" style="border-radius:12px;font-size:14px;font-weight:700;">${getInitials(c.name)}</div>
      <div class="list-item-content">
        <div class="list-item-title">${c.name}</div>
        <div class="list-item-sub">${[c.city, c.country].filter(Boolean).join(', ') || 'No location'} • ${c.phone || 'No phone'}</div>
      </div>
      <div class="list-item-right">
        ${c.pricing_plan ? `<span class="badge" style="background:#f0f7e6;color:#76B82A;">${c.pricing_plan}</span>` : ''}
        <i class="fas fa-chevron-right" style="color:#94a3b8;font-size:12px;margin-top:4px;display:block;"></i>
      </div>
    </div>`;
}

async function openClinic(id) {
  const content = document.getElementById('page-content');
  content.innerHTML = '<div class="loading"><div class="spinner"></div></div>';
  const res = await api.get(`/clinics/${id}`);
  const c = res.clinic;
  const dentists = res.dentists || [];
  const stats = res.stats || {};

  content.innerHTML = `
    <div class="fade-in">
      <div style="padding:12px 16px;background:white;border-bottom:1px solid #f1f5f9;display:flex;align-items:center;gap:10px;">
        <button onclick="navigateTo('clinics')" class="btn btn-ghost btn-sm"><i class="fas fa-arrow-left"></i></button>
        <div style="flex:1;font-size:16px;font-weight:700;">${c.name}</div>
        <button onclick="showEditClinicModal(${c.id})" class="btn btn-outline btn-sm"><i class="fas fa-edit"></i></button>
      </div>

      <div class="card" style="margin:12px 16px;">
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
          ${renderInfoField('City', c.city, 'fa-map-marker-alt')}
          ${renderInfoField('Country', c.country, 'fa-globe')}
          ${renderInfoField('Phone', c.phone, 'fa-phone')}
          ${renderInfoField('Email', c.email, 'fa-envelope')}
          ${renderInfoField('Plan', c.pricing_plan, 'fa-tag')}
          ${renderInfoField('Sales Rep', c.sales_rep, 'fa-user-tie')}
        </div>
      </div>

      <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;padding:0 16px 12px;">
        <div class="stat-card" style="--accent:#76B82A">
          <div class="stat-value">${stats.total || 0}</div>
          <div class="stat-label">Total Cases</div>
        </div>
        <div class="stat-card" style="--accent:#22c55e">
          <div class="stat-value">${stats.completed || 0}</div>
          <div class="stat-label">Completed</div>
        </div>
      </div>

      <div class="section-header">
        <div class="section-title">Dentists (${dentists.length})</div>
        <button onclick="showAddDentistModal(${c.id})" class="section-link">+ Add</button>
      </div>
      ${dentists.map(d => `
        <div class="list-item">
          <div class="list-avatar"><i class="fas fa-user-md"></i></div>
          <div class="list-item-content">
            <div class="list-item-title">${d.name}</div>
            <div class="list-item-sub">${d.specialty || 'General'} • ${d.phone || 'No phone'}</div>
          </div>
        </div>`).join('') || '<div style="padding:16px;text-align:center;color:#94a3b8;font-size:13px;">No dentists</div>'}
    </div>`;
}

function showAddClinicModal() {
  showModal('clinic-modal', `
    <div class="modal-handle"></div>
    <div class="modal-title"><i class="fas fa-clinic-medical text-primary"></i> Add Clinic</div>
    <div class="form-group"><label class="form-label">Clinic Name *</label>
      <input type="text" id="cl-name" class="form-input" placeholder="Clinic name"/></div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
      <div class="form-group"><label class="form-label">City</label>
        <input type="text" id="cl-city" class="form-input" placeholder="City"/></div>
      <div class="form-group"><label class="form-label">Country</label>
        <input type="text" id="cl-country" class="form-input" placeholder="Country"/></div>
    </div>
    <div class="form-group"><label class="form-label">Phone</label>
      <input type="tel" id="cl-phone" class="form-input" placeholder="+1-555-0000"/></div>
    <div class="form-group"><label class="form-label">Email</label>
      <input type="email" id="cl-email" class="form-input" placeholder="clinic@email.com"/></div>
    <div class="form-group"><label class="form-label">Pricing Plan</label>
      <select id="cl-plan" class="form-select">
        <option value="">— Select Plan —</option>
        <option>Basic</option><option>Standard</option><option>Premium</option>
      </select>
    </div>
    <div class="form-group"><label class="form-label">Address</label>
      <input type="text" id="cl-addr" class="form-input" placeholder="Street address"/></div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:8px;">
      <button onclick="closeModal('clinic-modal')" class="btn btn-ghost">Cancel</button>
      <button onclick="submitAddClinic()" class="btn btn-primary"><i class="fas fa-save"></i> Save</button>
    </div>
  `);
}

async function submitAddClinic() {
  const name = document.getElementById('cl-name')?.value.trim();
  if (!name) { showToast('Clinic name required', 'error'); return; }
  const res = await api.post('/clinics', {
    name, city: document.getElementById('cl-city')?.value,
    country: document.getElementById('cl-country')?.value,
    phone: document.getElementById('cl-phone')?.value,
    email: document.getElementById('cl-email')?.value,
    pricing_plan: document.getElementById('cl-plan')?.value,
    address: document.getElementById('cl-addr')?.value
  });
  if (res.success) {
    closeModal('clinic-modal');
    showToast('Clinic added!', 'success');
    renderClinicsPage();
  } else showToast(res.error || 'Failed', 'error');
}

function showAddDentistModal(clinicId) {
  showModal('dentist-modal', `
    <div class="modal-handle"></div>
    <div class="modal-title"><i class="fas fa-user-md text-primary"></i> Add Dentist</div>
    <div class="form-group"><label class="form-label">Name *</label>
      <input type="text" id="dt-name" class="form-input" placeholder="Dr. Name"/></div>
    <div class="form-group"><label class="form-label">Phone</label>
      <input type="tel" id="dt-phone" class="form-input" placeholder="+1-555-0000"/></div>
    <div class="form-group"><label class="form-label">Email</label>
      <input type="email" id="dt-email" class="form-input" placeholder="dr@email.com"/></div>
    <div class="form-group"><label class="form-label">Specialty</label>
      <select id="dt-spec" class="form-select">
        <option value="">— Select —</option>
        <option>General Dentist</option><option>Prosthodontist</option>
        <option>Implantologist</option><option>Orthodontist</option>
        <option>Oral Surgeon</option><option>Periodontist</option>
      </select>
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:8px;">
      <button onclick="closeModal('dentist-modal')" class="btn btn-ghost">Cancel</button>
      <button onclick="submitAddDentist(${clinicId})" class="btn btn-primary"><i class="fas fa-save"></i> Save</button>
    </div>
  `);
}

async function submitAddDentist(clinicId) {
  const name = document.getElementById('dt-name')?.value.trim();
  if (!name) { showToast('Name required', 'error'); return; }
  const res = await api.post('/dentists', {
    clinic_id: clinicId, name,
    phone: document.getElementById('dt-phone')?.value,
    email: document.getElementById('dt-email')?.value,
    specialty: document.getElementById('dt-spec')?.value
  });
  if (res.success) {
    closeModal('dentist-modal');
    showToast('Dentist added!', 'success');
    openClinic(clinicId);
  }
}

// ===== SEARCH PAGE =====
function renderSearchPage() {
  document.getElementById('page-content').innerHTML = `
    <div class="fade-in">
      <div class="search-bar" style="position:static;padding:16px;">
        <div class="search-input-wrap">
          <i class="fas fa-search"></i>
          <input type="text" id="global-search" class="form-input" style="border-radius:12px;padding:14px 14px 14px 40px;" 
            placeholder="Search cases, patients, clinics..." oninput="doGlobalSearch()"/>
        </div>
      </div>
      <div style="padding:0 16px 8px;display:flex;gap:8px;">
        <button class="chip active" onclick="setSearchType('cases')">Cases</button>
        <button class="chip" onclick="setSearchType('clinics')">Clinics</button>
        <button class="chip" onclick="setSearchType('dentists')">Dentists</button>
      </div>
      <div id="search-results">
        <div class="empty-state"><i class="fas fa-search"></i><h3>Start typing to search</h3></div>
      </div>
    </div>`;
  window.__searchType = 'cases';
}

function setSearchType(type) {
  window.__searchType = type;
  document.querySelectorAll('.chip').forEach(c => c.classList.remove('active'));
  event.target.classList.add('active');
  doGlobalSearch();
}

async function doGlobalSearch() {
  const q = document.getElementById('global-search')?.value.trim();
  const results = document.getElementById('search-results');
  if (!q) { results.innerHTML = '<div class="empty-state"><i class="fas fa-search"></i><h3>Type to search</h3></div>'; return; }

  const type = window.__searchType || 'cases';
  let res;
  if (type === 'cases') res = await api.get(`/cases?search=${encodeURIComponent(q)}`);
  else if (type === 'clinics') res = await api.get(`/clinics?search=${encodeURIComponent(q)}`);
  else res = await api.get(`/dentists?search=${encodeURIComponent(q)}`);

  const items = res.cases || res.clinics || res.dentists || [];
  if (!items.length) {
    results.innerHTML = '<div class="empty-state"><i class="fas fa-search"></i><h3>No results found</h3></div>';
    return;
  }

  if (type === 'cases') results.innerHTML = items.map(renderCaseCard).join('');
  else if (type === 'clinics') results.innerHTML = items.map(renderClinicItem).join('');
  else results.innerHTML = items.map(d => `
    <div class="list-item">
      <div class="list-avatar"><i class="fas fa-user-md"></i></div>
      <div class="list-item-content">
        <div class="list-item-title">${d.name}</div>
        <div class="list-item-sub">${d.clinic_name||'Independent'} • ${d.specialty||'General'}</div>
      </div>
    </div>`).join('');
}


// ===== REPORTS PAGE =====
async function renderReportsPage() {
  const content = document.getElementById('page-content');
  const [statsRes, logsRes] = await Promise.all([
    api.get('/cases/dashboard/stats'),
    api.get('/users/activity')
  ]);
  const stats = statsRes.stats || {};
  const logs = logsRes.logs || [];

  content.innerHTML = `
    <div class="fade-in">
      <div style="padding:16px 16px 8px;"><div class="section-title"><i class="fas fa-chart-bar text-primary"></i> Reports & Analytics</div></div>

      <!-- Summary Cards -->
      <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px;padding:0 16px 12px;">
        <div style="background:white;border-radius:10px;padding:12px;text-align:center;box-shadow:0 1px 4px rgba(0,0,0,0.06);">
          <div style="font-size:22px;font-weight:800;color:#76B82A">${stats.total||0}</div>
          <div style="font-size:10px;color:#64748b;text-transform:uppercase;">Total</div>
        </div>
        <div style="background:white;border-radius:10px;padding:12px;text-align:center;box-shadow:0 1px 4px rgba(0,0,0,0.06);">
          <div style="font-size:22px;font-weight:800;color:#3b82f6">${stats.active||0}</div>
          <div style="font-size:10px;color:#64748b;text-transform:uppercase;">Active</div>
        </div>
        <div style="background:white;border-radius:10px;padding:12px;text-align:center;box-shadow:0 1px 4px rgba(0,0,0,0.06);">
          <div style="font-size:22px;font-weight:800;color:#ef4444">${stats.delayed||0}</div>
          <div style="font-size:10px;color:#64748b;text-transform:uppercase;">Delayed</div>
        </div>
      </div>

      <!-- Status Chart -->
      ${(stats.by_status||[]).length > 0 ? `
      <div class="chart-container">
        <div class="chart-title"><i class="fas fa-chart-doughnut text-primary"></i> Cases by Status</div>
        <canvas id="status-chart" height="200"></canvas>
      </div>` : ''}

      <!-- Monthly Trend -->
      ${(stats.monthly||[]).length > 0 ? `
      <div class="chart-container">
        <div class="chart-title"><i class="fas fa-chart-line text-primary"></i> Monthly Trend</div>
        <canvas id="trend-chart" height="160"></canvas>
      </div>` : ''}

      <!-- Activity Log -->
      <div style="padding:8px 16px 4px;"><div class="section-title"><i class="fas fa-history text-primary"></i> Activity Log</div></div>
      ${logs.slice(0,20).map(l => `
        <div style="padding:10px 16px;border-bottom:1px solid #f1f5f9;display:flex;gap:10px;align-items:flex-start;">
          <div style="width:32px;height:32px;border-radius:50%;background:#f0f7e6;color:#76B82A;display:flex;align-items:center;justify-content:center;font-size:12px;flex-shrink:0;">
            <i class="fas fa-user"></i>
          </div>
          <div style="flex:1;">
            <div style="font-size:13px;font-weight:600;">${l.action}</div>
            <div style="font-size:11px;color:#64748b;">${l.user_name || 'System'} • ${timeAgo(l.created_at)}</div>
          </div>
        </div>`).join('') || '<div class="empty-state" style="padding:24px"><i class="fas fa-history"></i><p>No activity yet</p></div>'}
    </div>`;

  // Draw charts
  setTimeout(() => {
    const statusData = stats.by_status || [];
    const ctx1 = document.getElementById('status-chart');
    if (ctx1 && statusData.length) {
      new Chart(ctx1, {
        type: 'doughnut',
        data: {
          labels: statusData.map(s => s.status),
          datasets: [{ data: statusData.map(s => s.count),
            backgroundColor: ['#76B82A','#7c3aed','#d97706','#be185d','#c2410c','#065f46','#166534','#15803d','#4b5563','#dc2626'] }]
        },
        options: { responsive: true, plugins: { legend: { position: 'right', labels: { font: { size: 11 } } } } }
      });
    }
    const monthly = (stats.monthly || []).reverse();
    const ctx2 = document.getElementById('trend-chart');
    if (ctx2 && monthly.length) {
      new Chart(ctx2, {
        type: 'line',
        data: {
          labels: monthly.map(m => m.month),
          datasets: [{ data: monthly.map(m => m.count), borderColor: '#76B82A', backgroundColor: 'rgba(118,184,42,0.1)',
            fill: true, tension: 0.4, pointBackgroundColor: '#76B82A' }]
        },
        options: { responsive: true, plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true } } }
      });
    }
  }, 100);
}

// ===== NOTIFICATIONS PAGE =====
async function renderNotificationsPage() {
  const content = document.getElementById('page-content');
  const res = await api.get('/users/notifications');
  const notifs = res.notifications || [];

  const icons = { info: 'fa-info-circle', success: 'fa-check-circle', warning: 'fa-exclamation-triangle', error: 'fa-times-circle' };
  const colors = { info: '#3b82f6', success: '#76B82A', warning: '#f59e0b', error: '#ef4444' };

  content.innerHTML = `
    <div class="fade-in">
      <div style="padding:12px 16px;background:white;border-bottom:1px solid #f1f5f9;display:flex;align-items:center;gap:10px;">
        <button onclick="navigateTo('dashboard')" class="btn btn-ghost btn-sm"><i class="fas fa-arrow-left"></i></button>
        <div style="flex:1;font-size:16px;font-weight:700;">Notifications</div>
      </div>
      ${notifs.length ? notifs.map(n => `
        <div class="list-item" style="background:${n.is_read?'white':'#f0f7e6'};" onclick="markRead(${n.id})">
          <div style="width:40px;height:40px;border-radius:50%;background:${colors[n.type]||'#94a3b8'}22;color:${colors[n.type]||'#94a3b8'};display:flex;align-items:center;justify-content:center;font-size:16px;">
            <i class="fas ${icons[n.type]||'fa-bell'}"></i>
          </div>
          <div class="list-item-content">
            <div class="list-item-title">${n.title}</div>
            <div class="list-item-sub">${n.message}</div>
            <div style="font-size:10px;color:#94a3b8;margin-top:2px;">${timeAgo(n.created_at)}</div>
          </div>
          ${!n.is_read ? '<div style="width:8px;height:8px;border-radius:50%;background:#76B82A;flex-shrink:0;"></div>' : ''}
        </div>`).join('') : `
        <div class="empty-state">
          <i class="fas fa-bell-slash"></i>
          <h3>No notifications</h3>
          <p>You're all caught up!</p>
        </div>`}
    </div>`;
}

async function markRead(id) {
  await api.put(`/users/notifications/${id}/read`, {});
}

// ===== FINANCE DASHBOARD =====
async function renderFinanceDashboard() {
  const content = document.getElementById('page-content');
  const res = await api.get('/finance/dashboard');
  const dash = res.dashboard || {};

  content.innerHTML = `
    <div class="fade-in">
      <!-- Revenue Summary -->
      <div class="finance-summary">
        <div style="font-size:12px;opacity:0.8;text-transform:uppercase;letter-spacing:1px;">Total Revenue</div>
        <div class="finance-amount">$${(dash.total_revenue||0).toLocaleString('en', {minimumFractionDigits:2})}</div>
        <div style="font-size:13px;opacity:0.85;">Lifetime paid invoices</div>
      </div>

      <!-- Pending alert -->
      ${dash.pending_count > 0 ? `
      <div style="margin:0 16px 12px;background:#fef3c7;border-radius:12px;padding:14px;display:flex;align-items:center;gap:10px;">
        <i class="fas fa-exclamation-triangle" style="color:#d97706;font-size:20px;"></i>
        <div>
          <div style="font-weight:700;color:#92400e;">${dash.pending_count} Pending Invoice${dash.pending_count>1?'s':''}</div>
          <div style="font-size:12px;color:#78350f;">$${(dash.pending_amount||0).toLocaleString('en', {minimumFractionDigits:2})} outstanding</div>
        </div>
        <button onclick="navigateTo('invoices')" style="margin-left:auto;background:#d97706;border:none;color:white;border-radius:8px;padding:8px 12px;font-size:12px;font-weight:700;cursor:pointer;">View</button>
      </div>` : ''}

      <!-- Monthly Revenue Chart -->
      ${(dash.monthly_revenue||[]).length > 0 ? `
      <div class="chart-container">
        <div class="chart-title"><i class="fas fa-chart-bar text-primary"></i> Monthly Revenue</div>
        <canvas id="revenue-chart" height="150"></canvas>
      </div>` : ''}

      <!-- Top Clinics -->
      ${(dash.top_clinics||[]).length > 0 ? `
      <div style="padding:8px 16px 4px;"><div class="section-title"><i class="fas fa-trophy text-primary"></i> Top Clinics by Revenue</div></div>
      ${(dash.top_clinics||[]).map((c, i) => `
        <div class="list-item">
          <div class="list-avatar" style="background:#f0f7e6;color:#76B82A;font-weight:700;">${i+1}</div>
          <div class="list-item-content">
            <div class="list-item-title">${c.clinic_name || 'Unknown'}</div>
            <div class="list-item-sub">${c.invoices} invoices</div>
          </div>
          <div style="font-weight:700;color:#76B82A;">$${(c.revenue||0).toLocaleString()}</div>
        </div>`).join('')}` : ''}

      <!-- Recent Invoices -->
      <div style="padding:8px 16px 4px;"><div class="section-title">Recent Invoices</div></div>
      ${(dash.recent_invoices||[]).map(inv => renderInvoiceCard(inv)).join('') || '<div class="empty-state" style="padding:24px"><i class="fas fa-file-invoice"></i><p>No invoices yet</p></div>'}
    </div>`;

  setTimeout(() => {
    const monthly = (dash.monthly_revenue||[]).reverse();
    const ctx = document.getElementById('revenue-chart');
    if (ctx && monthly.length) {
      new Chart(ctx, {
        type: 'bar',
        data: {
          labels: monthly.map(m => m.month),
          datasets: [{ data: monthly.map(m => m.revenue||0), backgroundColor: 'rgba(118,184,42,0.7)', borderColor: '#76B82A', borderWidth: 2, borderRadius: 6 }]
        },
        options: { responsive: true, plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true } } }
      });
    }
  }, 100);
}

// ===== INVOICES PAGE =====
async function renderInvoicesPage() {
  const content = document.getElementById('page-content');
  const res = await api.get('/finance/invoices');
  const invoices = res.invoices || [];

  content.innerHTML = `
    <div class="fade-in">
      <div style="padding:12px 16px;display:flex;justify-content:space-between;align-items:center;background:white;border-bottom:1px solid #f1f5f9;">
        <div style="font-size:16px;font-weight:700;">Invoices</div>
        <button onclick="showCreateInvoiceModal()" class="btn btn-primary btn-sm"><i class="fas fa-plus"></i> New Invoice</button>
      </div>
      <div class="filter-chips">
        <button class="chip active" onclick="filterInvoices('')">All</button>
        <button class="chip" onclick="filterInvoices('Pending')">Pending</button>
        <button class="chip" onclick="filterInvoices('Paid')">Paid</button>
        <button class="chip" onclick="filterInvoices('Overdue')">Overdue</button>
      </div>
      <div id="invoice-list">
        ${invoices.length ? invoices.map(renderInvoiceCard).join('') : '<div class="empty-state"><i class="fas fa-file-invoice"></i><h3>No invoices</h3></div>'}
      </div>
    </div>`;
  window.__allInvoices = invoices;
}

function filterInvoices(status) {
  document.querySelectorAll('.chip').forEach(c => c.classList.remove('active'));
  event.target.classList.add('active');
  const filtered = status ? (window.__allInvoices||[]).filter(i => i.status === status) : (window.__allInvoices||[]);
  document.getElementById('invoice-list').innerHTML = filtered.length ? filtered.map(renderInvoiceCard).join('') :
    '<div class="empty-state"><i class="fas fa-filter"></i><h3>No matching invoices</h3></div>';
}

const INV_STATUS = { Pending: '#f59e0b', Paid: '#76B82A', Overdue: '#ef4444', Sent: '#3b82f6', Cancelled: '#94a3b8' };

function renderInvoiceCard(inv) {
  const color = INV_STATUS[inv.status] || '#94a3b8';
  return `
    <div class="invoice-card" onclick="openInvoice(${inv.id})">
      <div class="invoice-icon" style="background:${color}22;color:${color}">
        <i class="fas fa-file-invoice-dollar"></i>
      </div>
      <div style="flex:1;">
        <div style="font-weight:700;font-size:14px;">${inv.invoice_number}</div>
        <div style="font-size:12px;color:#64748b;">${inv.clinic_name||'—'} • ${inv.case_number||'—'}</div>
        <div style="font-size:11px;color:#94a3b8;">${formatDate(inv.created_at)}</div>
      </div>
      <div style="text-align:right;">
        <div style="font-weight:700;font-size:16px;">$${(inv.total||0).toFixed(2)}</div>
        <span class="badge" style="background:${color}22;color:${color};margin-top:4px;">${inv.status}</span>
      </div>
    </div>`;
}

async function openInvoice(id) {
  const res = await api.get(`/finance/invoices/${id}`);
  if (!res.invoice) return;
  const inv = res.invoice;
  const payments = res.payments || [];
  const procs = res.procedures || [];

  showModal('inv-detail-modal', `
    <div class="modal-handle"></div>
    <div class="modal-title"><i class="fas fa-file-invoice text-primary"></i> ${inv.invoice_number}</div>
    <div style="background:#f8fafc;border-radius:10px;padding:12px;margin-bottom:16px;">
      <div style="display:flex;justify-content:space-between;margin-bottom:8px;">
        <span style="font-size:12px;color:#64748b;">Clinic:</span><span style="font-weight:600;">${inv.clinic_name||'—'}</span>
      </div>
      <div style="display:flex;justify-content:space-between;margin-bottom:8px;">
        <span style="font-size:12px;color:#64748b;">Case:</span><span style="font-weight:600;">${inv.case_number||'—'} — ${inv.patient_name||''}</span>
      </div>
      <div style="display:flex;justify-content:space-between;margin-bottom:8px;">
        <span style="font-size:12px;color:#64748b;">Date:</span><span>${formatDate(inv.created_at)}</span>
      </div>
      <div style="display:flex;justify-content:space-between;">
        <span style="font-size:12px;color:#64748b;">Status:</span>
        <span class="badge" style="background:${(INV_STATUS[inv.status]||'#94a3b8')}22;color:${INV_STATUS[inv.status]||'#94a3b8'};">${inv.status}</span>
      </div>
    </div>

    ${procs.length ? `
    <div style="margin-bottom:16px;">
      <div style="font-size:12px;font-weight:700;color:#475569;text-transform:uppercase;margin-bottom:8px;">Procedures</div>
      ${procs.map(p => `<div style="display:flex;justify-content:space-between;padding:6px 0;border-bottom:1px solid #f1f5f9;">
        <span style="font-size:13px;">${p.procedure_name} × ${p.quantity}</span>
        <span style="font-weight:600;">$${(p.unit_price*p.quantity).toFixed(2)}</span>
      </div>`).join('')}
    </div>` : ''}

    <div style="background:#f0f7e6;border-radius:10px;padding:12px;margin-bottom:16px;">
      <div style="display:flex;justify-content:space-between;margin-bottom:4px;"><span style="font-size:13px;">Subtotal</span><span>$${(inv.subtotal||0).toFixed(2)}</span></div>
      ${inv.discount ? `<div style="display:flex;justify-content:space-between;margin-bottom:4px;"><span style="font-size:13px;color:#dc2626;">Discount</span><span style="color:#dc2626;">-$${inv.discount.toFixed(2)}</span></div>` : ''}
      ${inv.tax ? `<div style="display:flex;justify-content:space-between;margin-bottom:4px;"><span style="font-size:13px;">Tax</span><span>+$${inv.tax.toFixed(2)}</span></div>` : ''}
      ${inv.delivery_charge ? `<div style="display:flex;justify-content:space-between;margin-bottom:4px;"><span style="font-size:13px;">Delivery</span><span>+$${inv.delivery_charge.toFixed(2)}</span></div>` : ''}
      <div style="display:flex;justify-content:space-between;font-weight:800;font-size:16px;border-top:1px solid #c6e08a;padding-top:8px;margin-top:4px;">
        <span>Total</span><span style="color:#76B82A;">$${(inv.total||0).toFixed(2)}</span>
      </div>
    </div>

    ${payments.length ? `
    <div style="margin-bottom:16px;">
      <div style="font-size:12px;font-weight:700;color:#475569;text-transform:uppercase;margin-bottom:8px;">Payments Received</div>
      ${payments.map(p => `<div style="display:flex;justify-content:space-between;padding:6px 0;">
        <span style="font-size:13px;">${p.method} • ${formatDate(p.created_at)}</span>
        <span style="font-weight:700;color:#76B82A;">$${p.amount.toFixed(2)}</span>
      </div>`).join('')}
    </div>` : ''}

    ${inv.status !== 'Paid' ? `
    <button onclick="showRecordPaymentModal(${inv.id},${inv.total})" class="btn btn-primary btn-full">
      <i class="fas fa-credit-card"></i> Record Payment
    </button>` : '<div style="text-align:center;color:#76B82A;font-weight:700;"><i class="fas fa-check-circle"></i> Fully Paid</div>'}
  `);
}

function showRecordPaymentModal(invoiceId, total) {
  closeModal('inv-detail-modal');
  showModal('payment-modal', `
    <div class="modal-handle"></div>
    <div class="modal-title"><i class="fas fa-credit-card text-primary"></i> Record Payment</div>
    <div class="form-group"><label class="form-label">Amount *</label>
      <input type="number" id="pay-amount" class="form-input" value="${total||0}" step="0.01"/></div>
    <div class="form-group"><label class="form-label">Payment Method</label>
      <select id="pay-method" class="form-select">
        <option>Bank Transfer</option><option>Cash</option><option>Card</option><option>Cheque</option>
      </select>
    </div>
    <div class="form-group"><label class="form-label">Reference</label>
      <input type="text" id="pay-ref" class="form-input" placeholder="Transaction ID or reference..."/></div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;">
      <button onclick="closeModal('payment-modal')" class="btn btn-ghost">Cancel</button>
      <button onclick="submitPayment(${invoiceId})" class="btn btn-primary"><i class="fas fa-save"></i> Record</button>
    </div>
  `);
}

async function submitPayment(invoiceId) {
  const amount = parseFloat(document.getElementById('pay-amount')?.value) || 0;
  if (!amount) { showToast('Amount required', 'error'); return; }
  const res = await api.post('/finance/payments', {
    invoice_id: invoiceId, amount,
    method: document.getElementById('pay-method')?.value,
    reference: document.getElementById('pay-ref')?.value
  });
  if (res.success) {
    closeModal('payment-modal');
    showToast('Payment recorded!', 'success');
    renderInvoicesPage();
  }
}

async function showCreateInvoiceModal() {
  const casesRes = await api.get('/cases?status=Ready for Delivery&limit=50');
  const cases = casesRes.cases || [];

  showModal('create-inv-modal', `
    <div class="modal-handle"></div>
    <div class="modal-title"><i class="fas fa-file-invoice text-primary"></i> Create Invoice</div>
    <div class="form-group"><label class="form-label">Select Case *</label>
      <select id="inv-case" class="form-select">
        <option value="">— Select Case —</option>
        ${cases.map(c => `<option value="${c.id}">${c.case_number} — ${c.patient_name}</option>`).join('')}
      </select>
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
      <div class="form-group"><label class="form-label">Subtotal ($)</label>
        <input type="number" id="inv-sub" class="form-input" value="0" step="0.01"/></div>
      <div class="form-group"><label class="form-label">Discount ($)</label>
        <input type="number" id="inv-disc" class="form-input" value="0" step="0.01"/></div>
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
      <div class="form-group"><label class="form-label">Tax ($)</label>
        <input type="number" id="inv-tax" class="form-input" value="0" step="0.01"/></div>
      <div class="form-group"><label class="form-label">Delivery ($)</label>
        <input type="number" id="inv-del" class="form-input" value="0" step="0.01"/></div>
    </div>
    <div class="form-group"><label class="form-label">Due Date</label>
      <input type="date" id="inv-due" class="form-input"/></div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;">
      <button onclick="closeModal('create-inv-modal')" class="btn btn-ghost">Cancel</button>
      <button onclick="submitCreateInvoice()" class="btn btn-primary"><i class="fas fa-save"></i> Create</button>
    </div>
  `);
}

async function submitCreateInvoice() {
  const caseId = document.getElementById('inv-case')?.value;
  if (!caseId) { showToast('Select a case', 'error'); return; }
  const res = await api.post('/finance/invoices', {
    case_id: parseInt(caseId),
    subtotal: parseFloat(document.getElementById('inv-sub')?.value)||0,
    discount: parseFloat(document.getElementById('inv-disc')?.value)||0,
    tax: parseFloat(document.getElementById('inv-tax')?.value)||0,
    delivery_charge: parseFloat(document.getElementById('inv-del')?.value)||0,
    due_date: document.getElementById('inv-due')?.value
  });
  if (res.success) {
    closeModal('create-inv-modal');
    showToast(`Invoice ${res.invoice_number} created!`, 'success');
    renderInvoicesPage();
  } else showToast(res.error || 'Failed', 'error');
}

// ===== PAYMENTS PAGE =====
async function renderPaymentsPage() {
  const content = document.getElementById('page-content');
  const res = await api.get('/finance/invoices?status=Paid');
  const invoices = res.invoices || [];
  content.innerHTML = `
    <div class="fade-in">
      <div style="padding:12px 16px;font-size:16px;font-weight:700;background:white;border-bottom:1px solid #f1f5f9;">
        <i class="fas fa-credit-card text-primary"></i> Payments
      </div>
      <div style="padding:12px 16px;background:#f0f7e6;margin:0;display:flex;justify-content:space-between;align-items:center;">
        <div>
          <div style="font-size:12px;color:#5a9020;">Total Received</div>
          <div style="font-size:24px;font-weight:800;color:#3d6315;">$${invoices.reduce((s,i)=>s+(i.total||0),0).toLocaleString('en',{minimumFractionDigits:2})}</div>
        </div>
        <div style="font-size:36px;">💰</div>
      </div>
      ${invoices.length ? invoices.map(renderInvoiceCard).join('') : '<div class="empty-state"><i class="fas fa-credit-card"></i><h3>No payments yet</h3></div>'}
    </div>`;
}

// ===== PROFIT PAGE =====
async function renderProfitPage() {
  const content = document.getElementById('page-content');
  const year = new Date().getFullYear();
  const res = await api.get(`/finance/reports/profit?year=${year}`);
  const monthly = res.monthly || [];

  const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
  const total = monthly.reduce((s, m) => s + (m.revenue||0), 0);

  content.innerHTML = `
    <div class="fade-in">
      <div class="finance-summary">
        <div style="font-size:12px;opacity:0.8;text-transform:uppercase;">Revenue ${year}</div>
        <div class="finance-amount">$${total.toLocaleString('en',{minimumFractionDigits:2})}</div>
        <div style="font-size:13px;opacity:0.85;">${monthly.reduce((s,m)=>s+(m.cases||0),0)} paid cases</div>
      </div>

      ${monthly.length ? `
      <div class="chart-container">
        <div class="chart-title"><i class="fas fa-chart-area text-primary"></i> Monthly Profit ${year}</div>
        <canvas id="profit-chart" height="200"></canvas>
      </div>

      <div class="card" style="margin:0 16px;">
        ${monthly.map(m => {
          const idx = parseInt(m.month) - 1;
          const name = months[idx] || m.month;
          const pct = total > 0 ? ((m.revenue/total)*100).toFixed(1) : 0;
          return `<div style="display:flex;align-items:center;padding:10px 0;border-bottom:1px solid #f1f5f9;gap:12px;">
            <div style="width:36px;font-size:11px;font-weight:700;color:#76B82A;">${name}</div>
            <div style="flex:1;background:#f1f5f9;border-radius:100px;height:8px;overflow:hidden;">
              <div style="background:#76B82A;height:100%;width:${pct}%;border-radius:100px;"></div>
            </div>
            <div style="width:72px;text-align:right;font-weight:700;font-size:13px;">$${(m.revenue||0).toFixed(0)}</div>
          </div>`;
        }).join('')}
      </div>` : '<div class="empty-state"><i class="fas fa-chart-line"></i><h3>No revenue data yet</h3></div>'}
    </div>`;

  setTimeout(() => {
    const ctx = document.getElementById('profit-chart');
    if (ctx && monthly.length) {
      new Chart(ctx, {
        type: 'bar',
        data: {
          labels: monthly.map(m => months[parseInt(m.month)-1] || m.month),
          datasets: [{ label: 'Revenue $', data: monthly.map(m => m.revenue||0),
            backgroundColor: 'rgba(118,184,42,0.7)', borderColor: '#76B82A', borderWidth: 2, borderRadius: 8 }]
        },
        options: { responsive: true, plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true } } }
      });
    }
  }, 100);
}

// ===== MODAL HELPER =====
function showModal(id, html) {
  let overlay = document.getElementById(id + '-overlay');
  if (!overlay) {
    overlay = document.createElement('div');
    overlay.id = id + '-overlay';
    overlay.className = 'modal-overlay';
    overlay.onclick = (e) => { if (e.target === overlay) closeModal(id); };
    document.body.appendChild(overlay);
  }
  overlay.innerHTML = `<div class="modal">${html}</div>`;
  overlay.style.display = 'flex';
}

function closeModal(id) {
  const overlay = document.getElementById(id + '-overlay');
  if (overlay) overlay.style.display = 'none';
}

// ===== PROFILE MENU =====
function showProfileMenu() {
  showModal('profile-modal', `
    <div class="modal-handle"></div>
    <div style="text-align:center;margin-bottom:20px;">
      <div style="width:72px;height:72px;border-radius:50%;background:var(--primary);color:white;display:flex;align-items:center;justify-content:center;font-size:28px;font-weight:700;margin:0 auto 12px;">${getInitials(currentUser.name)}</div>
      <div style="font-size:18px;font-weight:700;">${currentUser.name}</div>
      <div style="font-size:13px;color:#64748b;">${currentUser.email}</div>
      <div style="margin-top:6px;display:flex;justify-content:center;gap:6px;">
        <span class="badge" style="background:#f0f7e6;color:#76B82A;">${currentUser.role}</span>
        <span class="badge" style="background:#eff6ff;color:#3b82f6;">${currentUser.account_type}</span>
      </div>
    </div>

    <div style="margin-bottom:16px;">
      <div class="list-item" style="border-radius:10px;margin-bottom:4px;" onclick="toggleDark();closeModal('profile-modal')">
        <i class="fas fa-${darkMode?'sun':'moon'}" style="color:#76B82A;width:20px;"></i>
        <div class="list-item-content" style="margin-left:8px;">
          <div class="list-item-title">${darkMode ? 'Light Mode' : 'Dark Mode'}</div>
        </div>
      </div>
      <div class="list-item" style="border-radius:10px;margin-bottom:4px;" onclick="navigateTo('notifications');closeModal('profile-modal')">
        <i class="fas fa-bell" style="color:#76B82A;width:20px;"></i>
        <div class="list-item-content" style="margin-left:8px;">
          <div class="list-item-title">Notifications</div>
        </div>
      </div>
    </div>

    <button onclick="doLogout()" class="btn btn-danger btn-full"><i class="fas fa-sign-out-alt"></i> Logout</button>
  `);
}

