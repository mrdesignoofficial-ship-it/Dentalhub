-- Seed Data for DentalHub Pro

-- Insert demo lab
INSERT OR IGNORE INTO labs (id, name, email, phone, address, city, country) VALUES
(1, 'DentalHub Demo Lab', 'admin@dentalhub.pro', '+1-555-0100', '123 Lab Street', 'New York', 'USA');

-- Insert demo users (password: "demo123" - hashed as simple sha256 placeholder)
INSERT OR IGNORE INTO users (id, lab_id, name, email, password_hash, role, account_type, phone) VALUES
(1, 1, 'Admin Owner', 'admin@dentalhub.pro', 'demo123hash', 'admin', 'operational', '+1-555-0101'),
(2, 1, 'Finance Manager', 'finance@dentalhub.pro', 'demo123hash', 'finance', 'finance', '+1-555-0102'),
(3, 1, 'Ali Technician', 'ali@dentalhub.pro', 'demo123hash', 'technician', 'operational', '+1-555-0103'),
(4, 1, 'Sara Designer', 'sara@dentalhub.pro', 'demo123hash', 'technician', 'operational', '+1-555-0104'),
(5, 1, 'Mike Manager', 'mike@dentalhub.pro', 'demo123hash', 'case_manager', 'operational', '+1-555-0105');

-- Insert demo clinics
INSERT OR IGNORE INTO clinics (id, lab_id, name, address, city, country, phone, email, pricing_plan) VALUES
(1, 1, 'Smile Dental Clinic', '456 Main St', 'New York', 'USA', '+1-555-0200', 'smile@clinic.com', 'Premium'),
(2, 1, 'BrightTeeth Practice', '789 Oak Ave', 'Boston', 'USA', '+1-555-0201', 'bright@clinic.com', 'Standard'),
(3, 1, 'City Orthodontics', '321 Park Blvd', 'Chicago', 'USA', '+1-555-0202', 'city@ortho.com', 'Basic');

-- Insert demo dentists
INSERT OR IGNORE INTO dentists (id, lab_id, clinic_id, name, phone, email, specialty) VALUES
(1, 1, 1, 'Dr. James Wilson', '+1-555-0300', 'jwilson@smile.com', 'Prosthodontist'),
(2, 1, 1, 'Dr. Emily Chen', '+1-555-0301', 'echen@smile.com', 'General Dentist'),
(3, 1, 2, 'Dr. Robert Brown', '+1-555-0302', 'rbrown@bright.com', 'Implantologist'),
(4, 1, 3, 'Dr. Sarah Davis', '+1-555-0303', 'sdavis@cityortho.com', 'Orthodontist');

-- Insert procedures library
INSERT OR IGNORE INTO procedures (id, lab_id, name, category, base_price) VALUES
(1, 1, 'Zirconia Crown', 'Crown', 120),
(2, 1, 'PMMA Crown', 'Crown', 85),
(3, 1, 'Emax Crown', 'Crown', 150),
(4, 1, 'Implant Crown', 'Implant', 180),
(5, 1, 'Surgical Guide', 'Implant', 250),
(6, 1, '3D Printed Model', 'Model', 45),
(7, 1, 'Aligner Setup', 'Aligner', 200),
(8, 1, 'Zirconia Bridge 3-Unit', 'Bridge', 320),
(9, 1, 'Full Arch Zirconia', 'Full Arch', 850),
(10, 1, 'Night Guard', 'Appliance', 95),
(11, 1, 'Partial Denture', 'Denture', 280),
(12, 1, 'Full Denture', 'Denture', 450);
