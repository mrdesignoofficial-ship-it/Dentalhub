// src/index.tsx - Main Hono Application
import { Hono } from 'hono'
import { cors } from 'hono/cors'
import { serveStatic } from 'hono/cloudflare-workers'

import authRoutes from './routes/auth'
import casesRoutes from './routes/cases'
import clinicsRoutes from './routes/clinics'
import dentistsRoutes from './routes/dentists'
import financeRoutes from './routes/finance'
import usersRoutes from './routes/users'
import proceduresRoutes from './routes/procedures'

type Bindings = { DB: D1Database }
const app = new Hono<{ Bindings: Bindings }>()

// CORS
app.use('/api/*', cors({
  origin: '*',
  allowMethods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowHeaders: ['Content-Type', 'Authorization'],
}))

// Static files
app.use('/static/*', serveStatic({ root: './public' }))

// API Routes
app.route('/api/auth', authRoutes)
app.route('/api/cases', casesRoutes)
app.route('/api/clinics', clinicsRoutes)
app.route('/api/dentists', dentistsRoutes)
app.route('/api/finance', financeRoutes)
app.route('/api/users', usersRoutes)
app.route('/api/procedures', proceduresRoutes)

// Health check
app.get('/api/health', (c) => c.json({ status: 'ok', app: 'DentalHub Pro', version: '1.0.0' }))

// Main SPA
app.get('*', (c) => {
  return c.html(getAppHtml())
})

function getAppHtml(): string {
  return `<!DOCTYPE html>
<html lang="en" data-theme="light">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
  <meta name="apple-mobile-web-app-capable" content="yes" />
  <meta name="mobile-web-app-capable" content="yes" />
  <meta name="theme-color" content="#76B82A" />
  <title>DentalHub Pro</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" />
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/axios@1.6.0/dist/axios.min.js"></script>
  <link rel="stylesheet" href="/static/styles.css" />
</head>
<body class="bg-gray-50 dark:bg-gray-900 min-h-screen">
  <div id="app"></div>
  <script src="/static/app.js"></script>
</body>
</html>`
}

export default app
