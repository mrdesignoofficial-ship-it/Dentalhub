// src/lib/auth.ts - Authentication utilities

export interface UserSession {
  id: number;
  lab_id: number;
  name: string;
  email: string;
  role: string;
  account_type: string;
}

// Simple hash (in production use proper bcrypt via a service)
export async function hashPassword(password: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(password + 'dentalhub_salt_2024');
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

export async function verifyPassword(password: string, hash: string): Promise<boolean> {
  const computed = await hashPassword(password);
  return computed === hash;
}

export function generateToken(): string {
  const array = new Uint8Array(32);
  crypto.getRandomValues(array);
  return Array.from(array).map(b => b.toString(16).padStart(2, '0')).join('');
}

export function generateCaseNumber(labId: number): string {
  const now = new Date();
  const year = now.getFullYear().toString().slice(-2);
  const month = (now.getMonth() + 1).toString().padStart(2, '0');
  const random = Math.floor(Math.random() * 9000 + 1000);
  return `LAB${labId}-${year}${month}-${random}`;
}

export function generateInvoiceNumber(labId: number): string {
  const now = new Date();
  const year = now.getFullYear().toString().slice(-2);
  const month = (now.getMonth() + 1).toString().padStart(2, '0');
  const random = Math.floor(Math.random() * 9000 + 1000);
  return `INV-${year}${month}-${random}`;
}

export async function getSession(db: D1Database, token: string): Promise<UserSession | null> {
  try {
    const result = await db.prepare(`
      SELECT u.id, u.lab_id, u.name, u.email, u.role, u.account_type
      FROM sessions s
      JOIN users u ON s.user_id = u.id
      WHERE s.token = ? AND s.expires_at > datetime('now') AND u.is_active = 1
    `).bind(token).first<UserSession>();
    return result || null;
  } catch {
    return null;
  }
}

export async function logActivity(
  db: D1Database,
  labId: number,
  userId: number,
  userName: string,
  action: string,
  entityType?: string,
  entityId?: number,
  details?: string
) {
  try {
    await db.prepare(`
      INSERT INTO activity_logs (lab_id, user_id, user_name, action, entity_type, entity_id, details)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `).bind(labId, userId, userName, action, entityType || null, entityId || null, details || null).run();
  } catch {
    // Don't fail on log errors
  }
}
