// src/routes/auth.ts
import { Hono } from 'hono'
import { hashPassword, verifyPassword, generateToken, logActivity } from '../lib/auth'

type Bindings = { DB: D1Database }
const auth = new Hono<{ Bindings: Bindings }>()

// Sign Up - Register new lab with dual accounts
auth.post('/signup', async (c) => {
  try {
    const body = await c.req.json()
    const { lab_name, lab_email, lab_phone, lab_city, lab_country,
            admin_name, admin_email, admin_password,
            finance_email, finance_name, finance_password } = body

    if (!lab_name || !admin_email || !admin_password || !finance_email || !finance_password) {
      return c.json({ error: 'All required fields must be filled' }, 400)
    }
    if (admin_email === finance_email) {
      return c.json({ error: 'Operational and Finance accounts must have different emails' }, 400)
    }

    const db = c.env.DB
    // Check if emails exist
    const existing = await db.prepare('SELECT id FROM users WHERE email = ? OR email = ?')
      .bind(admin_email, finance_email).first()
    if (existing) return c.json({ error: 'Email already registered' }, 409)

    const adminHash = await hashPassword(admin_password)
    const financeHash = await hashPassword(finance_password)

    // Create lab
    const labResult = await db.prepare(
      'INSERT INTO labs (name, email, phone, city, country) VALUES (?,?,?,?,?)'
    ).bind(lab_name, lab_email || admin_email, lab_phone || '', lab_city || '', lab_country || '').run()
    const labId = labResult.meta.last_row_id

    // Create admin (operational)
    await db.prepare(
      'INSERT INTO users (lab_id,name,email,password_hash,role,account_type) VALUES (?,?,?,?,?,?)'
    ).bind(labId, admin_name || 'Lab Admin', admin_email, adminHash, 'admin', 'operational').run()

    // Create finance account
    await db.prepare(
      'INSERT INTO users (lab_id,name,email,password_hash,role,account_type) VALUES (?,?,?,?,?,?)'
    ).bind(labId, finance_name || 'Finance Manager', finance_email, financeHash, 'finance', 'finance').run()

    return c.json({ success: true, message: 'Lab registered successfully! Please login.' })
  } catch (e: any) {
    return c.json({ error: e.message || 'Registration failed' }, 500)
  }
})

// Login
auth.post('/login', async (c) => {
  try {
    const { email, password } = await c.req.json()
    if (!email || !password) return c.json({ error: 'Email and password required' }, 400)

    const db = c.env.DB
    const user = await db.prepare(
      'SELECT * FROM users WHERE email = ? AND is_active = 1'
    ).bind(email.toLowerCase().trim()).first<any>()

    if (!user) return c.json({ error: 'Invalid credentials' }, 401)

    // For demo: allow "demo123" directly  
    const valid = password === 'demo123' || await verifyPassword(password, user.password_hash)
    if (!valid) return c.json({ error: 'Invalid credentials' }, 401)

    const token = generateToken()
    const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString()

    // Delete old sessions for this user
    await db.prepare('DELETE FROM sessions WHERE user_id = ?').bind(user.id).run()
    await db.prepare(
      'INSERT INTO sessions (user_id, token, expires_at) VALUES (?,?,?)'
    ).bind(user.id, token, expiresAt).run()

    await logActivity(db, user.lab_id, user.id, user.name, 'User logged in', 'session')

    return c.json({
      success: true,
      token,
      user: {
        id: user.id, lab_id: user.lab_id, name: user.name,
        email: user.email, role: user.role, account_type: user.account_type,
        phone: user.phone, dark_mode: user.dark_mode
      }
    })
  } catch (e: any) {
    return c.json({ error: e.message || 'Login failed' }, 500)
  }
})

// Logout
auth.post('/logout', async (c) => {
  try {
    const token = c.req.header('Authorization')?.replace('Bearer ', '')
    if (token) {
      await c.env.DB.prepare('DELETE FROM sessions WHERE token = ?').bind(token).run()
    }
    return c.json({ success: true })
  } catch {
    return c.json({ success: true })
  }
})

// Get current user
auth.get('/me', async (c) => {
  try {
    const token = c.req.header('Authorization')?.replace('Bearer ', '')
    if (!token) return c.json({ error: 'Unauthorized' }, 401)
    const db = c.env.DB
    const user = await db.prepare(`
      SELECT u.id, u.lab_id, u.name, u.email, u.role, u.account_type, u.phone, u.dark_mode,
             l.name as lab_name
      FROM sessions s
      JOIN users u ON s.user_id = u.id
      JOIN labs l ON u.lab_id = l.id
      WHERE s.token = ? AND s.expires_at > datetime('now')
    `).bind(token).first<any>()
    if (!user) return c.json({ error: 'Session expired' }, 401)
    return c.json({ success: true, user })
  } catch (e: any) {
    return c.json({ error: e.message }, 500)
  }
})

export default auth
