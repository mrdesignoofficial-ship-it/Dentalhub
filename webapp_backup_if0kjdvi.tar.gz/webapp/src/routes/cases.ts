// src/routes/cases.ts
import { Hono } from 'hono'
import { getSession, generateCaseNumber, generateInvoiceNumber, logActivity } from '../lib/auth'

type Bindings = { DB: D1Database }
const cases = new Hono<{ Bindings: Bindings }>()

// Middleware: require auth
cases.use('/*', async (c, next) => {
  const token = c.req.header('Authorization')?.replace('Bearer ', '')
  if (!token) return c.json({ error: 'Unauthorized' }, 401)
  const session = await getSession(c.env.DB, token)
  if (!session) return c.json({ error: 'Session expired' }, 401)
  c.set('session' as any, session)
  await next()
})

// GET /api/cases - list with filters
cases.get('/', async (c) => {
  const session = c.get('session' as any) as any
  const { status, clinic_id, dentist_id, technician_id, search, date_from, date_to, limit = '50', offset = '0' } = c.req.query()
  const db = c.env.DB

  let query = `
    SELECT c.*, cl.name as clinic_name, d.name as dentist_name,
           u.name as technician_name,
           (SELECT COUNT(*) FROM case_files cf WHERE cf.case_id = c.id) as file_count,
           (SELECT COUNT(*) FROM case_notes cn WHERE cn.case_id = c.id) as note_count
    FROM cases c
    LEFT JOIN clinics cl ON c.clinic_id = cl.id
    LEFT JOIN dentists d ON c.dentist_id = d.id
    LEFT JOIN users u ON c.assigned_technician_id = u.id
    WHERE c.lab_id = ?
  `
  const params: any[] = [session.lab_id]

  if (status) { query += ' AND c.status = ?'; params.push(status) }
  if (clinic_id) { query += ' AND c.clinic_id = ?'; params.push(clinic_id) }
  if (dentist_id) { query += ' AND c.dentist_id = ?'; params.push(dentist_id) }
  if (technician_id) { query += ' AND c.assigned_technician_id = ?'; params.push(technician_id) }
  if (search) { query += ' AND (c.case_number LIKE ? OR c.patient_name LIKE ?)'; params.push(`%${search}%`, `%${search}%`) }
  if (date_from) { query += ' AND c.creation_date >= ?'; params.push(date_from) }
  if (date_to) { query += ' AND c.creation_date <= ?'; params.push(date_to) }

  query += ' ORDER BY c.creation_date DESC LIMIT ? OFFSET ?'
  params.push(parseInt(limit), parseInt(offset))

  const result = await db.prepare(query).bind(...params).all<any>()
  return c.json({ success: true, cases: result.results, total: result.results.length })
})

// GET /api/cases/:id
cases.get('/:id', async (c) => {
  const session = c.get('session' as any) as any
  const db = c.env.DB
  const id = c.req.param('id')

  const caseData = await db.prepare(`
    SELECT c.*, cl.name as clinic_name, cl.phone as clinic_phone,
           d.name as dentist_name, d.phone as dentist_phone,
           u.name as technician_name, cb.name as created_by_name
    FROM cases c
    LEFT JOIN clinics cl ON c.clinic_id = cl.id
    LEFT JOIN dentists d ON c.dentist_id = d.id
    LEFT JOIN users u ON c.assigned_technician_id = u.id
    LEFT JOIN users cb ON c.created_by = cb.id
    WHERE c.id = ? AND c.lab_id = ?
  `).bind(id, session.lab_id).first<any>()

  if (!caseData) return c.json({ error: 'Case not found' }, 404)

  const [procedures, tracking, notes, files] = await Promise.all([
    db.prepare('SELECT * FROM case_procedures WHERE case_id = ?').bind(id).all<any>(),
    db.prepare('SELECT * FROM case_tracking WHERE case_id = ? ORDER BY created_at DESC').bind(id).all<any>(),
    db.prepare('SELECT * FROM case_notes WHERE case_id = ? ORDER BY created_at ASC').bind(id).all<any>(),
    db.prepare('SELECT * FROM case_files WHERE case_id = ? ORDER BY created_at DESC').bind(id).all<any>()
  ])

  return c.json({
    success: true,
    case: caseData,
    procedures: procedures.results,
    tracking: tracking.results,
    notes: notes.results,
    files: files.results
  })
})

// POST /api/cases - create new case
cases.post('/', async (c) => {
  const session = c.get('session' as any) as any
  const db = c.env.DB
  try {
    const body = await c.req.json()
    const caseNumber = generateCaseNumber(session.lab_id)

    const result = await db.prepare(`
      INSERT INTO cases (lab_id, case_number, patient_name, clinic_id, dentist_id,
        assigned_technician_id, appointment_date, expected_delivery_date,
        status, priority, shade, arch, notes, created_by)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)
    `).bind(
      session.lab_id, caseNumber, body.patient_name,
      body.clinic_id || null, body.dentist_id || null,
      body.assigned_technician_id || null, body.appointment_date || null,
      body.expected_delivery_date || null, body.status || 'Received',
      body.priority || 'Normal', body.shade || null, body.arch || null,
      body.notes || null, session.id
    ).run()

    const caseId = result.meta.last_row_id

    // Add procedures
    if (body.procedures?.length) {
      for (const p of body.procedures) {
        await db.prepare(
          'INSERT INTO case_procedures (case_id, procedure_id, procedure_name, quantity, unit_price, notes) VALUES (?,?,?,?,?,?)'
        ).bind(caseId, p.procedure_id || null, p.procedure_name, p.quantity || 1, p.unit_price || 0, p.notes || null).run()
      }
    }

    // Initial tracking
    await db.prepare(
      'INSERT INTO case_tracking (case_id, status, note, technician_id, technician_name) VALUES (?,?,?,?,?)'
    ).bind(caseId, 'Received', 'Case created', session.id, session.name).run()

    await logActivity(db, session.lab_id, session.id, session.name, 'Case created', 'case', caseId, `Case ${caseNumber}`)

    return c.json({ success: true, case_id: caseId, case_number: caseNumber })
  } catch (e: any) {
    return c.json({ error: e.message }, 500)
  }
})

// PUT /api/cases/:id - update case
cases.put('/:id', async (c) => {
  const session = c.get('session' as any) as any
  const db = c.env.DB
  const id = c.req.param('id')
  try {
    const body = await c.req.json()
    const existing = await db.prepare('SELECT * FROM cases WHERE id = ? AND lab_id = ?').bind(id, session.lab_id).first<any>()
    if (!existing) return c.json({ error: 'Case not found' }, 404)

    await db.prepare(`
      UPDATE cases SET patient_name=?, clinic_id=?, dentist_id=?,
        assigned_technician_id=?, appointment_date=?, expected_delivery_date=?,
        status=?, priority=?, shade=?, arch=?, notes=?,
        courier=?, tracking_number=?, dispatch_date=?, updated_at=datetime('now')
      WHERE id = ? AND lab_id = ?
    `).bind(
      body.patient_name || existing.patient_name,
      body.clinic_id || existing.clinic_id, body.dentist_id || existing.dentist_id,
      body.assigned_technician_id || existing.assigned_technician_id,
      body.appointment_date || existing.appointment_date,
      body.expected_delivery_date || existing.expected_delivery_date,
      body.status || existing.status, body.priority || existing.priority,
      body.shade || existing.shade, body.arch || existing.arch,
      body.notes || existing.notes, body.courier || existing.courier,
      body.tracking_number || existing.tracking_number,
      body.dispatch_date || existing.dispatch_date, id, session.lab_id
    ).run()

    // Log status change
    if (body.status && body.status !== existing.status) {
      await db.prepare(
        'INSERT INTO case_tracking (case_id, status, note, technician_id, technician_name) VALUES (?,?,?,?,?)'
      ).bind(id, body.status, body.status_note || `Status changed to ${body.status}`, session.id, session.name).run()
      await logActivity(db, session.lab_id, session.id, session.name,
        `Case status → ${body.status}`, 'case', parseInt(id))
    }

    return c.json({ success: true })
  } catch (e: any) {
    return c.json({ error: e.message }, 500)
  }
})

// POST /api/cases/:id/notes
cases.post('/:id/notes', async (c) => {
  const session = c.get('session' as any) as any
  const db = c.env.DB
  const id = c.req.param('id')
  const { message } = await c.req.json()
  if (!message) return c.json({ error: 'Message required' }, 400)

  await db.prepare(
    'INSERT INTO case_notes (case_id, user_id, user_name, user_role, message) VALUES (?,?,?,?,?)'
  ).bind(id, session.id, session.name, session.role, message).run()

  return c.json({ success: true })
})

// POST /api/cases/:id/files - upload file metadata
cases.post('/:id/files', async (c) => {
  const session = c.get('session' as any) as any
  const db = c.env.DB
  const id = c.req.param('id')
  const body = await c.req.json()

  await db.prepare(
    'INSERT INTO case_files (case_id, lab_id, file_name, file_type, file_url, file_size, uploaded_by, uploaded_by_name) VALUES (?,?,?,?,?,?,?,?)'
  ).bind(id, session.lab_id, body.file_name, body.file_type || null,
    body.file_url || '#', body.file_size || 0, session.id, session.name).run()

  await logActivity(db, session.lab_id, session.id, session.name,
    `File uploaded: ${body.file_name}`, 'case', parseInt(id))

  return c.json({ success: true })
})

// GET /api/cases/dashboard/stats
cases.get('/dashboard/stats', async (c) => {
  const session = c.get('session' as any) as any
  const db = c.env.DB
  const labId = session.lab_id

  const [total, active, ready, delayed, today, byStatus, monthly] = await Promise.all([
    db.prepare("SELECT COUNT(*) as count FROM cases WHERE lab_id = ?").bind(labId).first<any>(),
    db.prepare("SELECT COUNT(*) as count FROM cases WHERE lab_id = ? AND status NOT IN ('Completed','Cancelled')").bind(labId).first<any>(),
    db.prepare("SELECT COUNT(*) as count FROM cases WHERE lab_id = ? AND status = 'Ready for Delivery'").bind(labId).first<any>(),
    db.prepare("SELECT COUNT(*) as count FROM cases WHERE lab_id = ? AND expected_delivery_date < date('now') AND status NOT IN ('Completed','Cancelled')").bind(labId).first<any>(),
    db.prepare("SELECT COUNT(*) as count FROM cases WHERE lab_id = ? AND expected_delivery_date = date('now')").bind(labId).first<any>(),
    db.prepare("SELECT status, COUNT(*) as count FROM cases WHERE lab_id = ? GROUP BY status").bind(labId).all<any>(),
    db.prepare("SELECT strftime('%Y-%m', creation_date) as month, COUNT(*) as count FROM cases WHERE lab_id = ? GROUP BY month ORDER BY month DESC LIMIT 12").bind(labId).all<any>()
  ])

  return c.json({
    success: true,
    stats: {
      total: total?.count || 0,
      active: active?.count || 0,
      ready: ready?.count || 0,
      delayed: delayed?.count || 0,
      today_deliveries: today?.count || 0,
      by_status: byStatus.results,
      monthly: monthly.results
    }
  })
})

// DELETE /api/cases/:id (admin only)
cases.delete('/:id', async (c) => {
  const session = c.get('session' as any) as any
  if (session.role !== 'admin') return c.json({ error: 'Admin only' }, 403)
  const db = c.env.DB
  const id = c.req.param('id')
  await db.prepare('UPDATE cases SET is_cancelled = 1 WHERE id = ? AND lab_id = ?').bind(id, session.lab_id).run()
  await logActivity(db, session.lab_id, session.id, session.name, 'Case cancelled', 'case', parseInt(id))
  return c.json({ success: true })
})

export default cases
