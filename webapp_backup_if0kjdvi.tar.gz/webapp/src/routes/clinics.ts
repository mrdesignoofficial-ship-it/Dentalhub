// src/routes/clinics.ts
import { Hono } from 'hono'
import { getSession, logActivity } from '../lib/auth'

type Bindings = { DB: D1Database }
const clinics = new Hono<{ Bindings: Bindings }>()

clinics.use('/*', async (c, next) => {
  const token = c.req.header('Authorization')?.replace('Bearer ', '')
  if (!token) return c.json({ error: 'Unauthorized' }, 401)
  const session = await getSession(c.env.DB, token)
  if (!session) return c.json({ error: 'Session expired' }, 401)
  c.set('session' as any, session)
  await next()
})

// GET all clinics
clinics.get('/', async (c) => {
  const session = c.get('session' as any) as any
  const { search } = c.req.query()
  const db = c.env.DB
  let query = 'SELECT * FROM clinics WHERE lab_id = ? AND is_active = 1'
  const params: any[] = [session.lab_id]
  if (search) { query += ' AND name LIKE ?'; params.push(`%${search}%`) }
  query += ' ORDER BY name ASC'
  const result = await db.prepare(query).bind(...params).all<any>()
  return c.json({ success: true, clinics: result.results })
})

// GET single clinic with dentists
clinics.get('/:id', async (c) => {
  const session = c.get('session' as any) as any
  const db = c.env.DB
  const id = c.req.param('id')
  const clinic = await db.prepare('SELECT * FROM clinics WHERE id = ? AND lab_id = ?').bind(id, session.lab_id).first<any>()
  if (!clinic) return c.json({ error: 'Clinic not found' }, 404)
  const dentists = await db.prepare('SELECT * FROM dentists WHERE clinic_id = ? AND is_active = 1').bind(id).all<any>()
  const caseStats = await db.prepare(
    "SELECT COUNT(*) as total, SUM(CASE WHEN status = 'Completed' THEN 1 ELSE 0 END) as completed FROM cases WHERE clinic_id = ? AND lab_id = ?"
  ).bind(id, session.lab_id).first<any>()
  return c.json({ success: true, clinic, dentists: dentists.results, stats: caseStats })
})

// POST create clinic
clinics.post('/', async (c) => {
  const session = c.get('session' as any) as any
  const db = c.env.DB
  const body = await c.req.json()
  if (!body.name) return c.json({ error: 'Clinic name required' }, 400)
  const result = await db.prepare(
    'INSERT INTO clinics (lab_id, name, address, city, country, phone, email, pricing_plan, sales_rep, notes) VALUES (?,?,?,?,?,?,?,?,?,?)'
  ).bind(session.lab_id, body.name, body.address||null, body.city||null, body.country||null,
    body.phone||null, body.email||null, body.pricing_plan||null, body.sales_rep||null, body.notes||null).run()
  await logActivity(db, session.lab_id, session.id, session.name, `Clinic created: ${body.name}`, 'clinic', result.meta.last_row_id)
  return c.json({ success: true, id: result.meta.last_row_id })
})

// PUT update clinic
clinics.put('/:id', async (c) => {
  const session = c.get('session' as any) as any
  const db = c.env.DB
  const id = c.req.param('id')
  const body = await c.req.json()
  await db.prepare(
    "UPDATE clinics SET name=?,address=?,city=?,country=?,phone=?,email=?,pricing_plan=?,sales_rep=?,notes=?,updated_at=datetime('now') WHERE id=? AND lab_id=?"
  ).bind(body.name,body.address||null,body.city||null,body.country||null,body.phone||null,
    body.email||null,body.pricing_plan||null,body.sales_rep||null,body.notes||null,id,session.lab_id).run()
  return c.json({ success: true })
})

// DELETE (soft)
clinics.delete('/:id', async (c) => {
  const session = c.get('session' as any) as any
  if (session.role !== 'admin') return c.json({ error: 'Admin only' }, 403)
  await c.env.DB.prepare('UPDATE clinics SET is_active = 0 WHERE id = ? AND lab_id = ?').bind(c.req.param('id'), session.lab_id).run()
  return c.json({ success: true })
})

export default clinics
