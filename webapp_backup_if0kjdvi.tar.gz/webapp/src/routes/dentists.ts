// src/routes/dentists.ts
import { Hono } from 'hono'
import { getSession } from '../lib/auth'

type Bindings = { DB: D1Database }
const dentists = new Hono<{ Bindings: Bindings }>()

dentists.use('/*', async (c, next) => {
  const token = c.req.header('Authorization')?.replace('Bearer ', '')
  if (!token) return c.json({ error: 'Unauthorized' }, 401)
  const session = await getSession(c.env.DB, token)
  if (!session) return c.json({ error: 'Session expired' }, 401)
  c.set('session' as any, session)
  await next()
})

dentists.get('/', async (c) => {
  const session = c.get('session' as any) as any
  const { clinic_id, search } = c.req.query()
  const db = c.env.DB
  let query = 'SELECT d.*, c.name as clinic_name FROM dentists d LEFT JOIN clinics c ON d.clinic_id = c.id WHERE d.lab_id = ? AND d.is_active = 1'
  const params: any[] = [session.lab_id]
  if (clinic_id) { query += ' AND d.clinic_id = ?'; params.push(clinic_id) }
  if (search) { query += ' AND d.name LIKE ?'; params.push(`%${search}%`) }
  query += ' ORDER BY d.name ASC'
  const result = await db.prepare(query).bind(...params).all<any>()
  return c.json({ success: true, dentists: result.results })
})

dentists.get('/:id', async (c) => {
  const session = c.get('session' as any) as any
  const db = c.env.DB
  const dentist = await db.prepare(
    'SELECT d.*, c.name as clinic_name FROM dentists d LEFT JOIN clinics c ON d.clinic_id = c.id WHERE d.id = ? AND d.lab_id = ?'
  ).bind(c.req.param('id'), session.lab_id).first<any>()
  if (!dentist) return c.json({ error: 'Not found' }, 404)
  const cases = await db.prepare(
    'SELECT id, case_number, patient_name, status, creation_date FROM cases WHERE dentist_id = ? AND lab_id = ? ORDER BY creation_date DESC LIMIT 20'
  ).bind(c.req.param('id'), session.lab_id).all<any>()
  return c.json({ success: true, dentist, cases: cases.results })
})

dentists.post('/', async (c) => {
  const session = c.get('session' as any) as any
  const db = c.env.DB
  const body = await c.req.json()
  if (!body.name) return c.json({ error: 'Name required' }, 400)
  const result = await db.prepare(
    'INSERT INTO dentists (lab_id, clinic_id, name, phone, email, specialty, notes) VALUES (?,?,?,?,?,?,?)'
  ).bind(session.lab_id, body.clinic_id||null, body.name, body.phone||null, body.email||null, body.specialty||null, body.notes||null).run()
  return c.json({ success: true, id: result.meta.last_row_id })
})

dentists.put('/:id', async (c) => {
  const session = c.get('session' as any) as any
  const body = await c.req.json()
  await c.env.DB.prepare(
    "UPDATE dentists SET clinic_id=?,name=?,phone=?,email=?,specialty=?,notes=?,updated_at=datetime('now') WHERE id=? AND lab_id=?"
  ).bind(body.clinic_id||null, body.name, body.phone||null, body.email||null, body.specialty||null, body.notes||null, c.req.param('id'), session.lab_id).run()
  return c.json({ success: true })
})

dentists.delete('/:id', async (c) => {
  const session = c.get('session' as any) as any
  await c.env.DB.prepare('UPDATE dentists SET is_active = 0 WHERE id = ? AND lab_id = ?').bind(c.req.param('id'), session.lab_id).run()
  return c.json({ success: true })
})

export default dentists
