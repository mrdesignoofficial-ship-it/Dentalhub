// src/routes/finance.ts
import { Hono } from 'hono'
import { getSession, generateInvoiceNumber, logActivity } from '../lib/auth'

type Bindings = { DB: D1Database }
const finance = new Hono<{ Bindings: Bindings }>()

// Finance middleware - only finance or admin
finance.use('/*', async (c, next) => {
  const token = c.req.header('Authorization')?.replace('Bearer ', '')
  if (!token) return c.json({ error: 'Unauthorized' }, 401)
  const session = await getSession(c.env.DB, token)
  if (!session) return c.json({ error: 'Session expired' }, 401)
  if (session.account_type !== 'finance' && session.role !== 'admin') {
    return c.json({ error: 'Finance access required' }, 403)
  }
  c.set('session' as any, session)
  await next()
})

// GET invoices
finance.get('/invoices', async (c) => {
  const session = c.get('session' as any) as any
  const { status, clinic_id, date_from, date_to } = c.req.query()
  const db = c.env.DB
  let query = `
    SELECT i.*, c.name as clinic_name, cs.case_number, cs.patient_name
    FROM invoices i
    LEFT JOIN clinics c ON i.clinic_id = c.id
    LEFT JOIN cases cs ON i.case_id = cs.id
    WHERE i.lab_id = ?
  `
  const params: any[] = [session.lab_id]
  if (status) { query += ' AND i.status = ?'; params.push(status) }
  if (clinic_id) { query += ' AND i.clinic_id = ?'; params.push(clinic_id) }
  if (date_from) { query += ' AND i.created_at >= ?'; params.push(date_from) }
  if (date_to) { query += ' AND i.created_at <= ?'; params.push(date_to) }
  query += ' ORDER BY i.created_at DESC'
  const result = await db.prepare(query).bind(...params).all<any>()
  return c.json({ success: true, invoices: result.results })
})

// GET single invoice
finance.get('/invoices/:id', async (c) => {
  const session = c.get('session' as any) as any
  const db = c.env.DB
  const invoice = await db.prepare(`
    SELECT i.*, c.name as clinic_name, cs.case_number, cs.patient_name
    FROM invoices i LEFT JOIN clinics c ON i.clinic_id = c.id LEFT JOIN cases cs ON i.case_id = cs.id
    WHERE i.id = ? AND i.lab_id = ?
  `).bind(c.req.param('id'), session.lab_id).first<any>()
  if (!invoice) return c.json({ error: 'Not found' }, 404)
  const payments = await db.prepare('SELECT * FROM payments WHERE invoice_id = ?').bind(c.req.param('id')).all<any>()
  const procedures = await db.prepare('SELECT * FROM case_procedures WHERE case_id = ?').bind(invoice.case_id).all<any>()
  return c.json({ success: true, invoice, payments: payments.results, procedures: procedures.results })
})

// POST generate invoice for case
finance.post('/invoices', async (c) => {
  const session = c.get('session' as any) as any
  const db = c.env.DB
  const body = await c.req.json()
  if (!body.case_id) return c.json({ error: 'Case ID required' }, 400)

  const caseData = await db.prepare('SELECT * FROM cases WHERE id = ? AND lab_id = ?').bind(body.case_id, session.lab_id).first<any>()
  if (!caseData) return c.json({ error: 'Case not found' }, 404)

  const invoiceNumber = generateInvoiceNumber(session.lab_id)
  const subtotal = body.subtotal || 0
  const discount = body.discount || 0
  const tax = body.tax || 0
  const delivery = body.delivery_charge || 0
  const total = subtotal - discount + tax + delivery

  const result = await db.prepare(`
    INSERT INTO invoices (lab_id, case_id, invoice_number, clinic_id, clinic_name, subtotal, discount, tax, delivery_charge, total, status, due_date, notes)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)
  `).bind(session.lab_id, body.case_id, invoiceNumber, caseData.clinic_id, body.clinic_name||'',
    subtotal, discount, tax, delivery, total, body.status||'Pending', body.due_date||null, body.notes||null).run()

  await logActivity(db, session.lab_id, session.id, session.name, `Invoice created: ${invoiceNumber}`, 'invoice', result.meta.last_row_id)
  return c.json({ success: true, id: result.meta.last_row_id, invoice_number: invoiceNumber })
})

// PUT update invoice
finance.put('/invoices/:id', async (c) => {
  const session = c.get('session' as any) as any
  const db = c.env.DB
  const body = await c.req.json()
  const total = (body.subtotal||0) - (body.discount||0) + (body.tax||0) + (body.delivery_charge||0)
  await db.prepare(
    "UPDATE invoices SET subtotal=?,discount=?,tax=?,delivery_charge=?,total=?,status=?,due_date=?,notes=?,updated_at=datetime('now') WHERE id=? AND lab_id=?"
  ).bind(body.subtotal||0, body.discount||0, body.tax||0, body.delivery_charge||0, total,
    body.status||'Pending', body.due_date||null, body.notes||null, c.req.param('id'), session.lab_id).run()
  return c.json({ success: true })
})

// POST record payment
finance.post('/payments', async (c) => {
  const session = c.get('session' as any) as any
  const db = c.env.DB
  const body = await c.req.json()
  if (!body.invoice_id || !body.amount) return c.json({ error: 'Invoice ID and amount required' }, 400)

  await db.prepare(
    'INSERT INTO payments (lab_id, invoice_id, amount, method, reference, notes) VALUES (?,?,?,?,?,?)'
  ).bind(session.lab_id, body.invoice_id, body.amount, body.method||'Cash', body.reference||null, body.notes||null).run()

  // Check if fully paid
  const invoice = await db.prepare('SELECT * FROM invoices WHERE id = ?').bind(body.invoice_id).first<any>()
  if (invoice) {
    const totalPaid = await db.prepare('SELECT SUM(amount) as paid FROM payments WHERE invoice_id = ?').bind(body.invoice_id).first<any>()
    if ((totalPaid?.paid || 0) >= invoice.total) {
      await db.prepare("UPDATE invoices SET status='Paid', paid_date=date('now') WHERE id=?").bind(body.invoice_id).run()
    }
  }
  return c.json({ success: true })
})

// GET finance dashboard
finance.get('/dashboard', async (c) => {
  const session = c.get('session' as any) as any
  const db = c.env.DB
  const labId = session.lab_id

  const [totalRevenue, pending, monthly, topClinics, recentInvoices] = await Promise.all([
    db.prepare("SELECT SUM(total) as revenue FROM invoices WHERE lab_id = ? AND status='Paid'").bind(labId).first<any>(),
    db.prepare("SELECT COUNT(*) as count, SUM(total) as amount FROM invoices WHERE lab_id = ? AND status='Pending'").bind(labId).first<any>(),
    db.prepare("SELECT strftime('%Y-%m', created_at) as month, SUM(total) as revenue, COUNT(*) as count FROM invoices WHERE lab_id = ? AND status='Paid' GROUP BY month ORDER BY month DESC LIMIT 12").bind(labId).all<any>(),
    db.prepare("SELECT clinic_name, SUM(total) as revenue, COUNT(*) as invoices FROM invoices WHERE lab_id = ? AND status='Paid' GROUP BY clinic_id ORDER BY revenue DESC LIMIT 5").bind(labId).all<any>(),
    db.prepare("SELECT i.*, c.name as clinic_name FROM invoices i LEFT JOIN clinics c ON i.clinic_id = c.id WHERE i.lab_id = ? ORDER BY i.created_at DESC LIMIT 10").bind(labId).all<any>()
  ])

  return c.json({
    success: true,
    dashboard: {
      total_revenue: totalRevenue?.revenue || 0,
      pending_count: pending?.count || 0,
      pending_amount: pending?.amount || 0,
      monthly_revenue: monthly.results,
      top_clinics: topClinics.results,
      recent_invoices: recentInvoices.results
    }
  })
})

// GET profit reports
finance.get('/reports/profit', async (c) => {
  const session = c.get('session' as any) as any
  const db = c.env.DB
  const { year } = c.req.query()
  const y = year || new Date().getFullYear().toString()

  const monthly = await db.prepare(`
    SELECT strftime('%m', created_at) as month, 
           SUM(total) as revenue, COUNT(*) as cases
    FROM invoices 
    WHERE lab_id = ? AND strftime('%Y', created_at) = ? AND status = 'Paid'
    GROUP BY month ORDER BY month
  `).bind(session.lab_id, y).all<any>()

  return c.json({ success: true, year: y, monthly: monthly.results })
})

export default finance
