// src/routes/procedures.ts
import { Hono } from 'hono'
import { getSession } from '../lib/auth'

type Bindings = { DB: D1Database }
const procedures = new Hono<{ Bindings: Bindings }>()

procedures.use('/*', async (c, next) => {
  const token = c.req.header('Authorization')?.replace('Bearer ', '')
  if (!token) return c.json({ error: 'Unauthorized' }, 401)
  const session = await getSession(c.env.DB, token)
  if (!session) return c.json({ error: 'Session expired' }, 401)
  c.set('session' as any, session)
  await next()
})

procedures.get('/', async (c) => {
  const session = c.get('session' as any) as any
  const result = await c.env.DB.prepare(
    'SELECT * FROM procedures WHERE lab_id = ? AND is_active = 1 ORDER BY category, name'
  ).bind(session.lab_id).all<any>()
  return c.json({ success: true, procedures: result.results })
})

procedures.post('/', async (c) => {
  const session = c.get('session' as any) as any
  const body = await c.req.json()
  const result = await c.env.DB.prepare(
    'INSERT INTO procedures (lab_id, name, category, base_price, description) VALUES (?,?,?,?,?)'
  ).bind(session.lab_id, body.name, body.category||null, body.base_price||0, body.description||null).run()
  return c.json({ success: true, id: result.meta.last_row_id })
})

procedures.put('/:id', async (c) => {
  const session = c.get('session' as any) as any
  const body = await c.req.json()
  await c.env.DB.prepare(
    'UPDATE procedures SET name=?,category=?,base_price=?,description=? WHERE id=? AND lab_id=?'
  ).bind(body.name, body.category||null, body.base_price||0, body.description||null, c.req.param('id'), session.lab_id).run()
  return c.json({ success: true })
})

procedures.delete('/:id', async (c) => {
  const session = c.get('session' as any) as any
  await c.env.DB.prepare('UPDATE procedures SET is_active = 0 WHERE id = ? AND lab_id = ?').bind(c.req.param('id'), session.lab_id).run()
  return c.json({ success: true })
})

export default procedures
