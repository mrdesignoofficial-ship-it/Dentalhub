// src/routes/users.ts
import { Hono } from 'hono'
import { getSession } from '../lib/auth'

type Bindings = { DB: D1Database }
const users = new Hono<{ Bindings: Bindings }>()

users.use('/*', async (c, next) => {
  const token = c.req.header('Authorization')?.replace('Bearer ', '')
  if (!token) return c.json({ error: 'Unauthorized' }, 401)
  const session = await getSession(c.env.DB, token)
  if (!session) return c.json({ error: 'Session expired' }, 401)
  c.set('session' as any, session)
  await next()
})

// GET all users (admin only)
users.get('/', async (c) => {
  const session = c.get('session' as any) as any
  const db = c.env.DB
  const result = await db.prepare(
    'SELECT id, name, email, role, account_type, phone, is_active, created_at FROM users WHERE lab_id = ? ORDER BY name'
  ).bind(session.lab_id).all<any>()
  return c.json({ success: true, users: result.results })
})

// GET technicians only
users.get('/technicians', async (c) => {
  const session = c.get('session' as any) as any
  const result = await c.env.DB.prepare(
    "SELECT id, name, email, role FROM users WHERE lab_id = ? AND role IN ('technician','case_manager') AND is_active = 1 ORDER BY name"
  ).bind(session.lab_id).all<any>()
  return c.json({ success: true, technicians: result.results })
})

// PUT update preferences (dark mode, etc.)
users.put('/preferences', async (c) => {
  const session = c.get('session' as any) as any
  const body = await c.req.json()
  await c.env.DB.prepare('UPDATE users SET dark_mode = ? WHERE id = ?').bind(body.dark_mode ? 1 : 0, session.id).run()
  return c.json({ success: true })
})

// GET activity logs
users.get('/activity', async (c) => {
  const session = c.get('session' as any) as any
  const result = await c.env.DB.prepare(
    'SELECT * FROM activity_logs WHERE lab_id = ? ORDER BY created_at DESC LIMIT 100'
  ).bind(session.lab_id).all<any>()
  return c.json({ success: true, logs: result.results })
})

// GET notifications
users.get('/notifications', async (c) => {
  const session = c.get('session' as any) as any
  const result = await c.env.DB.prepare(
    'SELECT * FROM notifications WHERE (user_id = ? OR lab_id = ?) ORDER BY created_at DESC LIMIT 50'
  ).bind(session.id, session.lab_id).all<any>()
  return c.json({ success: true, notifications: result.results })
})

// PUT mark notification read
users.put('/notifications/:id/read', async (c) => {
  const session = c.get('session' as any) as any
  await c.env.DB.prepare('UPDATE notifications SET is_read = 1 WHERE id = ? AND (user_id = ? OR lab_id = ?)').bind(c.req.param('id'), session.id, session.lab_id).run()
  return c.json({ success: true })
})

export default users
